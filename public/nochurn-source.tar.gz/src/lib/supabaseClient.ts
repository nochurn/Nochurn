import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Browser-safe environment configuration (NEVER expose SUPABASE_SERVICE_ROLE_KEY)
const envUrl = typeof process !== 'undefined' ? process.env.NEXT_PUBLIC_SUPABASE_URL : undefined;
const envAnonKey = typeof process !== 'undefined' ? process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY : undefined;
const envSiteUrl = typeof process !== 'undefined' ? process.env.NEXT_PUBLIC_SITE_URL : undefined;

let supabaseInstance: SupabaseClient | null = null;
let configCache: {
  url: string;
  anonKey: string;
  siteUrl: string;
  oauthProviders: { google: boolean; microsoft: boolean };
} | null = null;

export interface AuthConfig {
  configured: boolean;
  url: string;
  anonKey: string;
  siteUrl: string;
  oauthProviders: {
    google: boolean;
    microsoft: boolean;
  };
  error?: string;
}

/**
 * Validates public Supabase credentials and returns whether the client is ready
 */
export function validateSupabaseConfig(url?: string, anonKey?: string): { valid: boolean; error?: string } {
  const checkUrl = url || envUrl;
  const checkKey = anonKey || envAnonKey;

  if (!checkUrl || !checkKey) {
    const missing = [];
    if (!checkUrl) missing.push('NEXT_PUBLIC_SUPABASE_URL');
    if (!checkKey) missing.push('NEXT_PUBLIC_SUPABASE_ANON_KEY');
    const msg = `Missing required Supabase configuration: ${missing.join(', ')}. Please verify your environment variables.`;
    if (process.env.NODE_ENV !== 'production') {
      console.warn(`[NoChurn Auth] Developer Warning: ${msg}`);
    }
    return { valid: false, error: msg };
  }

  return { valid: true };
}

/**
 * Fetch authoritative runtime public auth configuration from server
 */
export async function fetchAuthConfig(): Promise<AuthConfig> {
  if (configCache) {
    return {
      configured: true,
      url: configCache.url,
      anonKey: configCache.anonKey,
      siteUrl: configCache.siteUrl,
      oauthProviders: configCache.oauthProviders
    };
  }

  try {
    const res = await fetch('/api/auth/config');
    if (res.ok) {
      const data = await res.json();
      if (data.configured) {
        configCache = {
          url: data.url,
          anonKey: data.anonKey,
          siteUrl: data.siteUrl || window.location.origin,
          oauthProviders: data.oauthProviders || { google: false, microsoft: false }
        };
        return data;
      }
    }
  } catch (err) {
    console.warn('[NoChurn Auth] Could not fetch /api/auth/config, falling back to bundled env', err);
  }

  const siteUrl = envSiteUrl || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000');
  const valid = validateSupabaseConfig();

  return {
    configured: valid.valid,
    url: envUrl || '',
    anonKey: envAnonKey || '',
    siteUrl,
    oauthProviders: { google: false, microsoft: false },
    error: valid.error
  };
}

export function isSupabaseConfigured(): boolean {
  const url = configCache?.url || envUrl || '';
  const anonKey = configCache?.anonKey || envAnonKey || '';
  return Boolean(url && anonKey && !url.includes('placeholder'));
}

/**
 * Returns the singleton browser Supabase client
 */
export function getSupabase(): SupabaseClient {
  if (supabaseInstance) {
    return supabaseInstance;
  }

  const url = configCache?.url || envUrl || '';
  const anonKey = configCache?.anonKey || envAnonKey || '';

  if (!url || !anonKey) {
    if (process.env.NODE_ENV !== 'production') {
      console.error(
        '[NoChurn Auth] Supabase Client initialized without NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY.'
      );
    }
  }

  supabaseInstance = createClient(url || 'https://placeholder.supabase.co', anonKey || 'placeholder-key', {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storage: typeof window !== 'undefined' ? window.localStorage : undefined,
      flowType: 'pkce'
    }
  });

  return supabaseInstance;
}

export function updateSupabaseClient(url: string, anonKey: string): SupabaseClient {
  supabaseInstance = createClient(url, anonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storage: typeof window !== 'undefined' ? window.localStorage : undefined,
      flowType: 'pkce'
    }
  });
  return supabaseInstance;
}

export const supabase = getSupabase();
