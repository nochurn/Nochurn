/**
 * NoChurn Authoritative Razorpay Configuration & Payment Methods
 *
 * Supported Payment Methods:
 * - UPI (Google Pay, PhonePe, Paytm, BHIM, any UPI ID / QR)
 * - Credit Cards (Visa, Mastercard, Amex, RuPay, Diners)
 * - Debit Cards (Visa, Mastercard, RuPay, Maestro)
 * - Netbanking (All Indian banks: HDFC, ICICI, SBI, Axis, Kotak, etc.)
 * - Wallets (Paytm, PhonePe, Mobikwik, Amazon Pay, Freecharge)
 */

export interface RazorpayPaymentMethodConfig {
  upi: boolean;
  card: boolean;
  netbanking: boolean;
  wallet: boolean;
  emi: boolean;
  paylater: boolean;
}

/**
 * Authoritative one-time payment methods configuration for Razorpay Checkout.
 * Used for:
 * A. ₹1 trial verification
 * B. Annual plan activation
 * C. One-time upgrade payments
 * D. Failed-payment retry
 */
export const oneTimePaymentMethods: RazorpayPaymentMethodConfig = {
  upi: true,
  card: true,
  netbanking: true,
  wallet: true,
  emi: false,
  paylater: false
};

/**
 * Standard required disclosures
 */
export const ONE_TIME_PAYMENT_DISCLOSURE =
  'Pay securely via UPI, debit/credit card, netbanking, or wallet.';

export const MONTHLY_RECURRING_DISCLOSURE =
  'Monthly billing requires UPI AutoPay or a card mandate.';

export const RECURRING_MANDATE_DISCLOSURE = MONTHLY_RECURRING_DISCLOSURE;

/**
 * Authoritative pricing lookup (India-first SaaS in INR)
 * Matches server-side billing_plans table exactly
 */
export const AUTHORITATIVE_PLANS: Record<
  'starter' | 'growth' | 'pro',
  {
    name: string;
    monthlyInr: number;
    annualInr: number;
    formattedMonthly: string;
    formattedAnnual: string;
  }
> = {
  starter: {
    name: 'Starter',
    monthlyInr: 4999,
    annualInr: 49190.16,
    formattedMonthly: '₹4,999/month',
    formattedAnnual: '₹49,190.16/year'
  },
  growth: {
    name: 'Growth',
    monthlyInr: 12999,
    annualInr: 127910.16,
    formattedMonthly: '₹12,999/month',
    formattedAnnual: '₹127,910.16/year'
  },
  pro: {
    name: 'Pro',
    monthlyInr: 29999,
    annualInr: 295190.16,
    formattedMonthly: '₹29,999/month',
    formattedAnnual: '₹295,190.16/year'
  }
};

/**
 * Helper to build Razorpay Standard Checkout options for one-time payments
 * (₹1 trial verification, Annual plan activation, One-time upgrade payments, Failed-payment retry)
 * Checkout display order:
 * 1. UPI
 * 2. Card
 * 3. Netbanking
 * 4. Wallet
 */
export function buildRazorpayOneTimeOptions(params: {
  keyId: string;
  orderId: string;
  amountPaise: number;
  currency?: string;
  name?: string;
  description: string;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  notes?: Record<string, string>;
  handler: (response: {
    razorpay_payment_id: string;
    razorpay_order_id: string;
    razorpay_signature: string;
  }) => void;
  onDismiss?: () => void;
}) {
  return {
    key: params.keyId,
    amount: params.amountPaise,
    currency: params.currency || 'INR',
    name: params.name || 'NoChurn',
    description: params.description,
    order_id: params.orderId,
    prefill: {
      name: params.customerName || 'Founder',
      email: params.customerEmail || 'founder@nochurn.com',
      contact: params.customerPhone || ''
    },
    notes: params.notes || {},
    method: {
      upi: true,
      card: true,
      netbanking: true,
      wallet: true,
      emi: false,
      paylater: false
    },
    config: {
      display: {
        blocks: {
          preferred: {
            name: 'Pay via UPI, Cards, Netbanking or Wallet',
            instruments: [
              { method: 'upi' },
              { method: 'card' },
              { method: 'netbanking' },
              { method: 'wallet' }
            ]
          }
        },
        sequence: ['block.preferred'],
        preferences: {
          show_default_blocks: true
        }
      }
    },
    theme: {
      color: '#1E3A8A'
    },
    modal: {
      ondismiss: params.onDismiss || (() => {})
    },
    handler: params.handler
  };
}

/**
 * Helper to build Razorpay Checkout options for Recurring Subscriptions (Monthly)
 * Recurring payments require UPI AutoPay or card mandate
 */
export function buildRazorpaySubscriptionOptions(params: {
  keyId: string;
  subscriptionId: string;
  name?: string;
  description?: string;
  planName?: string;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  notes?: Record<string, string>;
  handler: (response: {
    razorpay_payment_id: string;
    razorpay_subscription_id: string;
    razorpay_signature: string;
  }) => void;
  onDismiss?: () => void;
}) {
  return {
    key: params.keyId,
    subscription_id: params.subscriptionId,
    name: params.name || 'NoChurn',
    description: params.description || (params.planName ? `${params.planName} Monthly Mandate` : 'NoChurn Monthly Mandate'),
    prefill: {
      name: params.customerName || 'Founder',
      email: params.customerEmail || 'founder@nochurn.com',
      contact: params.customerPhone || ''
    },
    notes: params.notes || {},
    method: {
      upi: true,
      card: true,
      netbanking: true,
      wallet: false,
      emi: false,
      paylater: false
    },
    config: {
      display: {
        blocks: {
          mandate: {
            name: 'UPI AutoPay & Card Mandate',
            instruments: [
              { method: 'upi' },
              { method: 'card' },
              { method: 'netbanking' }
            ]
          }
        },
        sequence: ['block.mandate'],
        preferences: {
          show_default_blocks: true
        }
      }
    },
    theme: {
      color: '#1E3A8A'
    },
    modal: {
      ondismiss: params.onDismiss || (() => {})
    },
    handler: params.handler
  };
}
