export type RiskCategory = 'Low' | 'Medium' | 'High' | 'Critical';

export interface RiskFactor {
  factor: string;
  points: number;
  description: string;
  category: 'payment' | 'usage' | 'support' | 'engagement';
}

export interface ChurnProbability {
  day30: number; // percentage e.g. 72%
  day60: number;
  day90: number;
}

export interface RetentionRecommendation {
  action: string;
  emailScript: string;
  recoveryProbability: number; // percentage 15-50%
  effortMinutes: number; // 15-60 min
  offerDiscount?: string;
  keyTalkingPoints?: string[];
  suggestedChannel?: 'Email' | 'Executive Call' | 'In-App Message' | 'Dedicated Slack';
}

export interface SupportTicket {
  id: string;
  subject: string;
  status: 'Open' | 'Pending' | 'Resolved';
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  createdAt: string;
  category: 'Billing' | 'Bug' | 'Feature Request' | 'Performance' | 'Onboarding';
}

export interface PaymentRecord {
  id: string;
  date: string;
  amount: number;
  status: 'Succeeded' | 'Failed' | 'Refunded' | 'Disputed' | 'Retried';
  invoiceId: string;
}

export interface LoginHistoryPoint {
  week: string;
  activeUsers: number;
  sessionsCount: number;
  durationMinutes: number;
}

export interface RiskTrendPoint {
  month: string;
  score: number;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  companyDomain: string;
  avatarUrl?: string;
  plan: 'Starter' | 'Growth' | 'Enterprise' | 'Pro';
  mrr: number;
  ltv: number;
  customerSince: string;
  lastLoginDays: number;
  openTicketsCount: number;
  paymentStatus: 'Current' | 'Retried' | 'Failed' | 'Disputed';
  usageTrendPercentage: number; // e.g. -65 means down 65%, +20 means up 20%
  emailOpenRate: number; // e.g. 12%
  
  // Gemini AI Analysis
  riskScore: number; // 0-100
  riskCategory: RiskCategory;
  topFactors: RiskFactor[];
  churnProbability: ChurnProbability;
  recommendedAction: string;
  retentionRecommendation?: RetentionRecommendation;
  lastAnalyzedAt: string;
  isAiAnalyzed: boolean;
  
  // Historical telemetry
  supportTickets: SupportTicket[];
  paymentHistory: PaymentRecord[];
  loginHistory: LoginHistoryPoint[];
  riskTrend: RiskTrendPoint[];
  
  // Status
  status: 'active' | 'saved' | 'churned';
  outcomeStatus?: 'recovered' | 'churned';
  churnReason?: ChurnReasonType;
  churnReasonDetail?: string;
  rescuePlaybookUsed?: string;
  mrrProtected?: number;
  savedDate?: string;
  savedNotes?: string;
  workspaceId?: string;
  customerId?: string; // alias/unique key in workspace
  startDate?: string;
  lastPaymentDate?: string;
  failedPaymentsCount?: number;
  loginFrequency14Days?: number;
  sessionDurationAvg?: number;
  featureUsageCount?: number;
  lastLoginDate?: string;
  tickets30Days?: number;
  avgResolutionTime?: number;
  lastTicketDate?: string;
  satisfactionScore?: number;
  clickRate30Days?: number;
  npsScore?: number;
  scoringSource?: 'gemini-3.1-flash-lite' | 'gemini-3.8-flash' | 'rule-based-fallback';
  
  // 5 Health Pillars & Action System
  healthPillars?: HealthPillars;
  owner?: string;
  adminName?: string;
  companyCity?: string;
  renewalDaysLeft?: number;
  activeSeats?: number;
  totalSeats?: number;
  isDemo?: boolean;
}

export interface HealthPillars {
  productScore: number;      // 0-100 (35% weight)
  billingScore: number;      // 0-100 (25% weight)
  supportScore: number;      // 0-100 (15% weight)
  relationshipScore: number; // 0-100 (15% weight)
  engagementScore: number;   // 0-100 (10% weight)
  rootCauseDiagnosis: string;
  seatUtilizationRate?: number;
  activeSeats?: number;
  totalSeats?: number;
  renewalDaysLeft?: number;
  unresolvedBugDays?: number;
  championLastActiveDays?: number;
}

export type ActionStatus = 'pending' | 'contacted' | 'followed_up' | 'recovered' | 'churned' | 'false_alert';

export type ChurnReasonType =
  | 'pricing'
  | 'missing_feature'
  | 'poor_onboarding'
  | 'support_issue'
  | 'competitor'
  | 'company_closed'
  | 'payment_failure'
  | 'unknown';

export interface ActionEmailDraft {
  subject: string;
  body: string;
  channel: string;
  effortMinutes?: number;
}

export interface CustomerRetentionAction {
  id: string;
  customerId: string;
  customerName: string;
  companyCity?: string;
  adminName?: string;
  ownerEmail: string;
  priorityRank: number;
  priorityScore: number;
  mrr: number;
  riskScore: number;
  whyAtRisk: string;
  recommendedAction: string;
  actionEmailDraft?: ActionEmailDraft;
  status: ActionStatus;
  assignedTo: string;
  dueDate?: string;
  followUpDate?: string;
  outcomeRecordedAt?: string;
  mrrProtected?: number;
  churnReason?: ChurnReasonType;
  churnNotes?: string;
  interventionUsed?: string;
  competitorName?: string;
  contactAttempts?: number;
}

export interface CohortMonthRecord {
  month: string;
  highRiskCount: number;
  actionedCount: number;
  rescuedCount: number;
  churnedCount: number;
  savedMrr: number;
  winRate: number;
}

export interface ChurnReasonStats {
  reason: ChurnReasonType;
  label: string;
  percentage: number;
  count: number;
  mrrLost: number;
  preventiveFix: string;
}

export interface OnboardingState {
  currentStep: 1 | 2 | 3 | 4;
  completedAt?: string;
  hasImportedData: boolean;
  importedSource: 'csv' | 'demo' | 'razorpay';
  importedRecordsCount: number;
  firstActionTaken: boolean;
  firstActionCustomerId?: string;
  productTourCompleted: boolean;
  isOpen: boolean;
}

export interface ImportHistoryRecord {
  importId: string;
  workspaceId: string;
  source: 'CSV' | 'PDF' | 'Razorpay' | 'Mixpanel' | 'Intercom' | 'Manual';
  fileName: string;
  startedAt: string;
  completedAt: string;
  totalRows: number;
  validRows: number;
  failedRows: number;
  status: 'completed' | 'failed' | 'processing';
  errorSummary?: string;
  invalidRows?: Array<{ row: number; field?: string; reason?: string; data?: Record<string, string>; errorReason?: string }>;
  documentSummary?: string;
  fileType?: 'csv' | 'pdf';
}

export interface ManualCustomerInput {
  name: string;
  customerId: string;
  email?: string;
  plan?: 'Starter' | 'Growth' | 'Enterprise';
  mrr: number;
  lastLoginDate?: string;
  paymentStatus: 'Current' | 'Failed' | 'Retried';
  failedPaymentsCount?: number;
  ticketsLast30Days?: number;
  satisfactionScore?: number;
  emailOpenRate?: number;
}

export interface IntegrationStatus {
  id: 'razorpay' | 'mixpanel' | 'intercom' | 'sendgrid' | 'supabase' | string;
  name: string;
  category: 'billing' | 'usage' | 'support' | 'engagement' | 'database';
  icon: string;
  description: string;
  isConnected: boolean;
  lastSyncAt: string | null;
  syncedRecordsCount: number;
  syncFrequency: 'Every 24 Hours' | 'Real-time' | 'Manual';
  apiKeyMasked?: string;
  statusText: string;
}

export interface DailyAlert {
  id: string;
  timestamp: string;
  title: string;
  customersCount: number;
  mrrAtRisk: number;
  customers: {
    id: string;
    name: string;
    score: number;
    mrr: number;
    action: string;
  }[];
  sentViaEmail: boolean;
  sentViaSlack: boolean;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  type: 'ai_analysis' | 'retention_action' | 'data_sync' | 'security' | 'billing';
}

export interface UserSession {
  id: string;
  device: string;
  location: string;
  ip: string;
  lastActive: string;
  isCurrent: boolean;
  createdAt?: string;
  browser?: string;
  os?: string;
}

export interface PaymentMethod {
  id: string;
  brand: string; // 'visa' | 'mastercard' | 'rupay' | 'upi'
  last4: string;
  expMonth: number;
  expYear: number;
  isDefault: boolean;
  cardholderName?: string;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  company: string;
  phone?: string;
  role: 'Admin' | 'Analyst' | 'Viewer';
  plan: 'Starter' | 'Growth' | 'Pro';
  selectedPlan?: string;
  billingCycle?: 'monthly' | 'annual';
  planPrice?: number;
  billingStatus?: 'trialing' | 'pending_payment' | 'active' | 'cancelled';
  trialStartDate?: string;
  trialEndDate?: string;
  paymentStatus?: 'pending' | 'paid' | 'not_added' | 'failed' | 'active';
  cardLast4?: string;
  cardBrand?: string;
  cardExp?: string;
  cardholderName?: string;
  paymentMethods?: PaymentMethod[];
  razorpayCustomerId?: string;
  razorpaySubscriptionId?: string;
  subscriptionStartDate?: string;
  currentPeriodEnd?: string;
  workspaceId?: string;
  isEmailVerified: boolean;
  twoFactorEnabled: boolean;
  twoFactorMethod?: 'authenticator' | 'sms';
  twoFactorSecret?: string;
  backupCodes: string[];
  failedLoginAttempts: number;
  lockoutUntil?: string | null;
  lastLoginAt: string;
  createdAt: string;
  rememberMe?: boolean;
}

export interface BillingPlan {
  id: string;
  tier: 'starter' | 'growth' | 'pro';
  billing_cycle: 'monthly' | 'annual';
  name: string;
  monthly_amount_paise: number;
  billing_amount_paise: number;
  currency: 'INR';
  period: 'monthly' | 'yearly';
  interval: number;
  discount_percentage: number;
  razorpay_plan_id: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionRecord {
  id: string;
  user_id?: string;
  tier: 'starter' | 'growth' | 'pro';
  billing_cycle: 'monthly' | 'annual';
  billing_plan_id: string;
  razorpay_plan_id: string;
  razorpay_subscription_id: string;
  status: 'pending' | 'incomplete' | 'active' | 'halted' | 'cancelled' | 'past_due';
  created_at: string;
  updated_at: string;
}

export interface AuthState {
  user: UserProfile | null;
  isAuthenticated: boolean;
  token?: string;
  requiresTwoFactor?: boolean;
  pendingTwoFactorUser?: UserProfile | null;
}

export interface PricingTier {
  id: string;
  name: string;
  monthlyPrice: number;
  customersIncluded: string;
  isPopular?: boolean;
  features: string[];
}

export const PRICING_TIERS: PricingTier[] = [
  {
    id: 'starter',
    name: 'Starter',
    monthlyPrice: 4999,
    customersIncluded: 'Up to 500 customers',
    features: [
      'Basic churn risk score (0-100)',
      'Daily 9:00 AM email digests',
      'Razorpay & CSV data ingestion',
      'Standard retention email templates',
      'Community & email support'
    ]
  },
  {
    id: 'growth',
    name: 'Growth',
    monthlyPrice: 12999,
    customersIncluded: 'Up to 2,500 customers',
    isPopular: true,
    features: [
      'Gemini 3.8 Flash AI predictions (30/60/90d)',
      'Automated personalized retention playbooks',
      'Real-time Slack webhook alerts',
      'Mixpanel & Intercom 24h auto-sync',
      'Interactive ROI Calculator & PDF exports',
      'Priority founder email support'
    ]
  },
  {
    id: 'pro',
    name: 'Pro Enterprise',
    monthlyPrice: 29999,
    customersIncluded: 'Up to 10,000 customers',
    features: [
      'Dedicated Customer Success Manager',
      'Custom Gemini AI prompts & tuned weights',
      'Bi-directional webhook retention automations',
      'Multi-role RBAC & SOC 2 compliance package',
      'Custom data pipeline integrations',
      'SLA guarantee (99.9% uptime)'
    ]
  }
];
