import React, { useState } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Sparkles,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  MoreVertical,
  UserCheck,
  AlertCircle,
  TrendingDown,
  TrendingUp,
  FileSpreadsheet,
  Download
} from 'lucide-react';
import { Customer } from '../types';
import { formatCurrency, getRiskColorClass } from '../utils/formatters';

interface CustomerTableViewProps {
  customers: Customer[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  onPageChange: (p: number) => void;
  onLimitChange: (l: number) => void;
  onSearchChange: (s: string) => void;
  searchValue: string;
  onFilterChange: (key: string, value: string) => void;
  filters: {
    riskLevel: string;
    mrrRange: string;
    plan: string;
    factor: string;
  };
  onSortChange: (sortBy: string) => void;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  onSelectCustomer: (cust: Customer) => void;
  onBatchAnalyze: () => void;
  isBatchAnalyzing: boolean;
  onMarkSaved: (id: string) => void;
}

export const CustomerTableView: React.FC<CustomerTableViewProps> = ({
  customers,
  total,
  page,
  limit,
  totalPages,
  onPageChange,
  onLimitChange,
  onSearchChange,
  searchValue,
  onFilterChange,
  filters,
  onSortChange,
  sortBy,
  sortOrder,
  onSelectCustomer,
  onBatchAnalyze,
  isBatchAnalyzing,
  onMarkSaved
}) => {
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const getSortIcon = (field: string) => {
    if (sortBy !== field) return <ArrowUpDown className="w-3 h-3 text-gray-400" />;
    return sortOrder === 'asc' ? (
      <ArrowUp className="w-3 h-3 text-blue-900" />
    ) : (
      <ArrowDown className="w-3 h-3 text-blue-900" />
    );
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-xs overflow-hidden">
      {/* Table Header & Controls Bar */}
      <div className="p-4 border-b border-gray-200 bg-gray-50/50 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-gray-900 leading-tight">Customer Retention Pipeline</h3>
            <p className="text-xs text-gray-700 mt-0.5">
              Showing {customers.length} of {total} monitored SaaS customers
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onBatchAnalyze}
              disabled={isBatchAnalyzing}
              className="px-3.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-200 animate-spin-slow" />
              {isBatchAnalyzing ? 'Running Gemini AI Scoring...' : 'Batch Score with Gemini'}
            </button>

            <a
              href="/api/export?format=csv"
              className="px-3 py-1.5 bg-white hover:bg-gray-50 text-gray-700 border border-gray-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              download
            >
              <Download className="w-3.5 h-3.5 text-gray-500" />
              Export CSV
            </a>
          </div>
        </div>

        {/* Filters Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2 border-t border-gray-200/60 text-xs">
          {/* Search Box */}
          <div className="col-span-2 sm:col-span-1">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Filter table..."
                value={searchValue}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-8 pr-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-900"
              />
            </div>
          </div>

          {/* Risk Filter */}
          <div>
            <select
              value={filters.riskLevel}
              onChange={(e) => onFilterChange('riskLevel', e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs text-gray-800 focus:outline-none focus:ring-1 focus:ring-blue-900"
            >
              <option value="all">Risk: All Levels</option>
              <option value="critical">Critical (86-100)</option>
              <option value="high">High (61-85)</option>
              <option value="medium">Medium (31-60)</option>
              <option value="low">Low (0-30)</option>
            </select>
          </div>

          {/* MRR Range */}
          <div>
            <select
              value={filters.mrrRange}
              onChange={(e) => onFilterChange('mrrRange', e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs text-gray-800 focus:outline-none focus:ring-1 focus:ring-blue-900"
            >
              <option value="all">MRR: All Amounts</option>
              <option value="<500">&lt; $500 /mo</option>
              <option value="500-1500">$500 - $1,500 /mo</option>
              <option value=">1500">&gt; $1,500 /mo</option>
            </select>
          </div>

          {/* Plan */}
          <div>
            <select
              value={filters.plan}
              onChange={(e) => onFilterChange('plan', e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs text-gray-800 focus:outline-none focus:ring-1 focus:ring-blue-900"
            >
              <option value="all">Plan: All Tiers</option>
              <option value="Enterprise">Enterprise</option>
              <option value="Growth">Growth</option>
              <option value="Starter">Starter</option>
            </select>
          </div>

          {/* Key Factor */}
          <div>
            <select
              value={filters.factor}
              onChange={(e) => onFilterChange('factor', e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs text-gray-800 focus:outline-none focus:ring-1 focus:ring-blue-900"
            >
              <option value="all">Factor: All Drivers</option>
              <option value="payment">Billing / Payment Issues</option>
              <option value="usage">Low Usage / Inactive</option>
              <option value="support">Unresolved Tickets</option>
              <option value="email">Low Email Opens</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-gray-700">
          <thead className="bg-gray-50/80 border-b border-gray-200 text-gray-600 font-semibold uppercase tracking-wider text-[10px]">
            <tr>
              <th
                onClick={() => onSortChange('name')}
                className="py-3 px-4 cursor-pointer hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Customer</span>
                  {getSortIcon('name')}
                </div>
              </th>

              <th
                onClick={() => onSortChange('riskScore')}
                className="py-3 px-3 cursor-pointer hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Risk Score</span>
                  {getSortIcon('riskScore')}
                </div>
              </th>

              <th
                onClick={() => onSortChange('mrr')}
                className="py-3 px-3 cursor-pointer hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>MRR</span>
                  {getSortIcon('mrr')}
                </div>
              </th>

              <th className="py-3 px-3">Plan</th>

              <th
                onClick={() => onSortChange('lastLogin')}
                className="py-3 px-3 cursor-pointer hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Last Login</span>
                  {getSortIcon('lastLogin')}
                </div>
              </th>

              <th className="py-3 px-3">Tickets</th>
              <th className="py-3 px-3">Payment</th>
              <th className="py-3 px-3">Top Risk Factor</th>
              <th className="py-3 px-3">Recommended Action</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-gray-100">
            {customers.length === 0 ? (
              <tr>
                <td colSpan={10} className="py-10 text-center text-gray-700">
                  <AlertCircle className="w-6 h-6 mx-auto text-gray-400 mb-2" />
                  No customers match the active filters or search terms.
                </td>
              </tr>
            ) : (
              customers.map((cust) => {
                const riskClasses = getRiskColorClass(cust.riskCategory);
                const isMenuOpen = activeMenuId === cust.id;

                return (
                  <tr
                    key={cust.id}
                    className={`hover:bg-blue-50/40 transition-colors cursor-pointer ${
                      cust.status === 'saved' ? 'bg-emerald-50/20' : ''
                    }`}
                    onClick={() => onSelectCustomer(cust)}
                  >
                    {/* Name & Domain */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-blue-900 text-white font-bold text-[11px] flex items-center justify-center shrink-0">
                          {cust.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-gray-900 truncate">{cust.name}</div>
                          <div className="text-[11px] text-gray-700 truncate">{cust.email}</div>
                        </div>
                      </div>
                    </td>

                    {/* Risk Score */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`px-2 py-0.5 rounded-full font-bold text-[11px] flex items-center gap-1 ${riskClasses.badge}`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${riskClasses.dot}`}></span>
                          {cust.riskScore}
                        </span>
                        {cust.isAiAnalyzed && (
                          <Sparkles className="w-3 h-3 text-blue-900" title="Analyzed with Gemini" />
                        )}
                      </div>
                    </td>

                    {/* MRR */}
                    <td className="py-3 px-3 font-semibold text-gray-900 whitespace-nowrap">
                      {formatCurrency(cust.mrr)}
                    </td>

                    {/* Plan */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="text-[11px] font-medium text-gray-700 bg-gray-100 px-2 py-0.5 rounded">
                        {cust.plan}
                      </span>
                    </td>

                    {/* Days Since Login */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`font-medium ${cust.lastLoginDays > 14 ? 'text-red-600 font-semibold' : 'text-gray-700'}`}>
                        {cust.lastLoginDays}d ago
                      </span>
                    </td>

                    {/* Open Tickets */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      {cust.openTicketsCount > 0 ? (
                        <span className="text-amber-700 font-semibold bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                          {cust.openTicketsCount} open
                        </span>
                      ) : (
                        <span className="text-gray-700">0</span>
                      )}
                    </td>

                    {/* Payment Status */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          cust.paymentStatus === 'Current'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : cust.paymentStatus === 'Retried'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-red-50 text-red-700 border border-red-200'
                        }`}
                      >
                        {cust.paymentStatus}
                      </span>
                    </td>

                    {/* Top Risk Factor */}
                    <td className="py-3 px-3 max-w-[180px] truncate" title={cust.topFactors?.[0]?.factor}>
                      <span className="text-[11px] text-gray-700 truncate block">
                        {cust.topFactors?.[0]?.factor || 'Low risk metrics'}
                      </span>
                    </td>

                    {/* Recommended Action */}
                    <td className="py-3 px-3 max-w-[190px] truncate">
                      <span className="text-[11px] font-medium text-blue-900 truncate block">
                        {cust.recommendedAction || 'Send check-in'}
                      </span>
                    </td>

                    {/* Action Buttons */}
                    <td className="py-3 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onSelectCustomer(cust)}
                          className="px-2.5 py-1 text-[11px] font-semibold text-blue-900 hover:bg-blue-50 rounded-md transition-colors"
                        >
                          View Details
                        </button>

                        {cust.status !== 'saved' ? (
                          <button
                            onClick={() => onMarkSaved(cust.id)}
                            title="Mark customer as retained / saved"
                            className="p-1 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                            Saved
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-4 border-t border-gray-200 bg-gray-50/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-700">
        <div className="flex items-center gap-2">
          <span>Rows per page:</span>
          <select
            value={limit}
            onChange={(e) => onLimitChange(Number(e.target.value))}
            className="px-2 py-1 bg-white border border-gray-200 rounded text-xs text-gray-800 focus:outline-none"
          >
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
          <span className="text-gray-700">
            Page {page} of {totalPages || 1}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onPageChange(page - 1)}
            disabled={page <= 1}
            className="p-1.5 bg-white border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {Array.from({ length: Math.min(5, totalPages || 1) }, (_, i) => {
            const p = i + 1;
            return (
              <button
                key={p}
                onClick={() => onPageChange(p)}
                className={`w-7 h-7 rounded-lg text-xs font-semibold transition-colors ${
                  page === p
                    ? 'bg-blue-900 text-white shadow-xs'
                    : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
              >
                {p}
              </button>
            );
          })}

          <button
            onClick={() => onPageChange(page + 1)}
            disabled={page >= totalPages}
            className="p-1.5 bg-white border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
