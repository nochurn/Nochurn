import React from 'react';
import {
  BarChart3,
  PieChart,
  TrendingDown,
  ShieldAlert,
  AlertTriangle,
  Flame,
  CheckCircle2,
  DollarSign
} from 'lucide-react';
import { Customer } from '../types';
import { formatCurrency } from '../utils/formatters';

interface AnalyticsViewProps {
  customers: Customer[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ customers }) => {
  const totalMrr = customers.reduce((acc, c) => acc + c.mrr, 0);

  // Categorize
  const critical = customers.filter((c) => c.riskScore >= 86);
  const high = customers.filter((c) => c.riskScore >= 61 && c.riskScore < 86);
  const medium = customers.filter((c) => c.riskScore >= 31 && c.riskScore < 61);
  const low = customers.filter((c) => c.riskScore < 31);

  const criticalMrr = critical.reduce((acc, c) => acc + c.mrr, 0);
  const highMrr = high.reduce((acc, c) => acc + c.mrr, 0);
  const mediumMrr = medium.reduce((acc, c) => acc + c.mrr, 0);
  const lowMrr = low.reduce((acc, c) => acc + c.mrr, 0);

  // Top churn factors calculation
  const factorMap: Record<string, { count: number; points: number }> = {};
  customers.forEach((c) => {
    c.topFactors?.forEach((f) => {
      if (!factorMap[f.factor]) {
        factorMap[f.factor] = { count: 0, points: 0 };
      }
      factorMap[f.factor].count += 1;
      factorMap[f.factor].points += f.points;
    });
  });

  const sortedFactors = Object.entries(factorMap)
    .map(([factor, data]) => ({ factor, ...data }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs">
        <h2 className="text-xl font-bold text-gray-900">Portfolio Churn Analytics</h2>
        <p className="text-xs text-gray-700 mt-1">
          Macro cohort trends, revenue at risk distributions, and systemic factor diagnostics.
        </p>
      </div>

      {/* 4 Risk Cohort Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Critical Red */}
        <div className="bg-white p-4 rounded-xl border border-red-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-red-700">Critical (86-100)</span>
            <Flame className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-black text-red-600 mt-2">{critical.length} Accounts</div>
          <div className="text-xs text-gray-700 mt-1">
            MRR: <strong>{formatCurrency(criticalMrr)}</strong> ({Math.round((criticalMrr / totalMrr) * 100)}%)
          </div>
        </div>

        {/* High Orange */}
        <div className="bg-white p-4 rounded-xl border border-orange-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-orange-700">High Risk (61-85)</span>
            <AlertTriangle className="w-4 h-4 text-orange-600" />
          </div>
          <div className="text-2xl font-black text-orange-600 mt-2">{high.length} Accounts</div>
          <div className="text-xs text-gray-700 mt-1">
            MRR: <strong>{formatCurrency(highMrr)}</strong> ({Math.round((highMrr / totalMrr) * 100)}%)
          </div>
        </div>

        {/* Medium Yellow */}
        <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-amber-800">Medium Risk (31-60)</span>
            <TrendingDown className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-amber-700 mt-2">{medium.length} Accounts</div>
          <div className="text-xs text-gray-700 mt-1">
            MRR: <strong>{formatCurrency(mediumMrr)}</strong> ({Math.round((mediumMrr / totalMrr) * 100)}%)
          </div>
        </div>

        {/* Low Green */}
        <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-emerald-800">Low Risk (0-30)</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700 mt-2">{low.length} Accounts</div>
          <div className="text-xs text-gray-700 mt-1">
            MRR: <strong>{formatCurrency(lowMrr)}</strong> ({Math.round((lowMrr / totalMrr) * 100)}%)
          </div>
        </div>
      </div>

      {/* Visual Proportion Breakdown Bar */}
      <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-gray-900">
          <span>MRR Distribution by Churn Risk Tier</span>
          <span className="text-gray-700">Total: {formatCurrency(totalMrr)}</span>
        </div>

        {/* Visual Bar */}
        <div className="w-full h-7 rounded-xl overflow-hidden flex shadow-inner">
          <div
            style={{ width: `${(criticalMrr / totalMrr) * 100}%` }}
            className="bg-red-500 hover:opacity-90 transition-opacity flex items-center justify-center text-[10px] font-bold text-white"
            title={`Critical: ${formatCurrency(criticalMrr)}`}
          >
            {Math.round((criticalMrr / totalMrr) * 100)}%
          </div>
          <div
            style={{ width: `${(highMrr / totalMrr) * 100}%` }}
            className="bg-orange-500 hover:opacity-90 transition-opacity flex items-center justify-center text-[10px] font-bold text-white"
            title={`High: ${formatCurrency(highMrr)}`}
          >
            {Math.round((highMrr / totalMrr) * 100)}%
          </div>
          <div
            style={{ width: `${(mediumMrr / totalMrr) * 100}%` }}
            className="bg-amber-400 hover:opacity-90 transition-opacity flex items-center justify-center text-[10px] font-bold text-gray-900"
            title={`Medium: ${formatCurrency(mediumMrr)}`}
          >
            {Math.round((mediumMrr / totalMrr) * 100)}%
          </div>
          <div
            style={{ width: `${(lowMrr / totalMrr) * 100}%` }}
            className="bg-emerald-500 hover:opacity-90 transition-opacity flex items-center justify-center text-[10px] font-bold text-white"
            title={`Low: ${formatCurrency(lowMrr)}`}
          >
            {Math.round((lowMrr / totalMrr) * 100)}%
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs pt-1">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-500"></span>
            <span className="text-gray-700">Critical ({formatCurrency(criticalMrr)})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-orange-500"></span>
            <span className="text-gray-700">High ({formatCurrency(highMrr)})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-400"></span>
            <span className="text-gray-700">Medium ({formatCurrency(mediumMrr)})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
            <span className="text-gray-700">Low ({formatCurrency(lowMrr)})</span>
          </div>
        </div>
      </div>

      {/* Top 5 Root Causes Diagnostic */}
      <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-blue-900" />
          Top 5 Systematic Churn Drivers Across SaaS Accounts
        </h3>

        <div className="space-y-3">
          {sortedFactors.map((f, idx) => (
            <div key={idx} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-gray-800">{f.factor}</span>
                <span className="text-gray-700">
                  Affecting <strong>{f.count} accounts</strong> (avg weight +{Math.round(f.points / f.count)} pts)
                </span>
              </div>
              <div className="w-full bg-gray-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-blue-900 h-full rounded-full transition-all"
                  style={{ width: `${Math.min(100, (f.count / customers.length) * 100 * 2.5)}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
