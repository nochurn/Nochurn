import React from 'react';
import {
  LayoutDashboard,
  Users,
  Sparkles,
  Database,
  BarChart3,
  Calculator,
  BellRing,
  CreditCard,
  ShieldCheck,
  TrendingUp,
  Gift,
  Laptop,
  Flame,
  Layers,
  Target
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  totalCustomers: number;
  atRiskCount: number;
  onOpenPricing: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onNavigate,
  totalCustomers,
  atRiskCount,
  onOpenPricing
}) => {
  const menuItems = [
    {
      id: 'action-queue',
      label: "Today's Action Queue",
      icon: Flame,
      badge: 'P1 Urgent',
      badgeColor: 'bg-red-100 text-red-800 font-extrabold animate-pulse'
    },
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'closed-loop',
      label: 'Closed-Loop Learning',
      icon: Layers,
      badge: '73% Rescued',
      badgeColor: 'bg-emerald-100 text-emerald-800 font-bold'
    },
    {
      id: 'roadmap',
      label: 'Roadmap & Metrics',
      icon: Target,
      badge: 'v2.0-PROD',
      badgeColor: 'bg-blue-100 text-blue-900 font-bold'
    },
    {
      id: 'customers',
      label: 'Customers',
      icon: Users,
      badge: totalCustomers ? `${totalCustomers}` : null
    },
    {
      id: 'playbooks',
      label: 'Retention Playbooks',
      icon: Sparkles,
      badge: atRiskCount > 0 ? `${atRiskCount} At Risk` : null,
      badgeColor: 'bg-orange-100 text-orange-800'
    },
    {
      id: 'integrations',
      label: 'Import Data',
      icon: Database,
      badge: '4 APIs'
    },
    {
      id: 'analytics',
      label: 'Analytics',
      icon: BarChart3,
      badge: null
    },
    {
      id: 'roi',
      label: 'ROI & Reports',
      icon: Calculator,
      badge: '14x ROI',
      badgeColor: 'bg-emerald-100 text-emerald-800'
    },
    {
      id: 'alerts',
      label: 'Daily Alerts & Slack',
      icon: BellRing,
      badge: null
    },
    {
      id: 'pricing',
      label: 'Pricing & Plans',
      icon: CreditCard,
      badge: null
    },
    {
      id: 'settings/billing',
      label: 'Billing & Plan',
      icon: CreditCard,
      badge: 'Trial',
      badgeColor: 'bg-blue-100 text-blue-900'
    },
    {
      id: 'settings/security',
      label: 'Security & 2FA',
      icon: ShieldCheck,
      badge: 'Active'
    },
    {
      id: 'settings/sessions',
      label: 'Active Sessions',
      icon: Laptop,
      badge: null
    },
    {
      id: 'admin/db-test',
      label: 'Database & Isolation Test',
      icon: Database,
      badge: 'Admin',
      badgeColor: 'bg-emerald-100 text-emerald-800 font-bold'
    }
  ];

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col justify-between shrink-0 h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto">
      <div className="p-3">
        <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-gray-700">
          Core Engine
        </div>

        <nav className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-blue-900 text-white shadow-xs font-semibold'
                    : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-gray-500'}`} />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                      isActive
                        ? 'bg-blue-800 text-blue-100'
                        : item.badgeColor || 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Growth Plan & Referral Widget */}
      <div className="p-3 border-t border-gray-100 bg-gray-50/70">
        <div className="p-3 bg-white rounded-xl border border-gray-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
              Growth Plan
            </span>
            <span className="text-xs font-bold text-gray-900">$299/mo</span>
          </div>

          <div className="mt-2 text-[11px] text-gray-700 flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>
              <strong>$4,200 MRR</strong> saved this month (14x return)
            </span>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <button
              onClick={onOpenPricing}
              className="flex-1 text-center py-1.5 px-2 rounded-lg bg-blue-900 hover:bg-blue-800 text-white text-[11px] font-semibold transition-colors"
            >
              Upgrade to Pro
            </button>
            <button
              onClick={onOpenPricing}
              title="Refer & Earn 1 Month Free"
              className="p-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-600 transition-colors"
            >
              <Gift className="w-3.5 h-3.5 text-blue-900" />
            </button>
          </div>
        </div>

        <div className="mt-2.5 px-1 flex items-center justify-between text-[10px] text-gray-700">
          <span>Auto-sync: Every 24h</span>
          <span className="text-emerald-700 font-medium">All 4 APIs Online</span>
        </div>
      </div>
    </aside>
  );
};
