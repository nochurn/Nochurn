import React, { useState, useRef } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import {
  Calculator,
  DollarSign,
  TrendingUp,
  Printer,
  Download,
  CheckCircle2,
  FileText,
  ShieldCheck,
  Calendar,
  Sparkles,
  Sliders,
  Settings2,
  X,
  ArrowRight
} from 'lucide-react';
import { Customer } from '../types';
import { formatCurrency } from '../utils/formatters';
import { generateRoiPdfReport } from '../utils/generatePdfReport';

interface RoiCalculatorViewProps {
  customers: Customer[];
  onShowToast?: (text: string, type?: 'success' | 'info' | 'error') => void;
}

export const RoiCalculatorView: React.FC<RoiCalculatorViewProps> = ({ customers, onShowToast }) => {
  const actualSaved = customers.filter((c) => c.status === 'saved');
  const actualSavedMrr = actualSaved.reduce((sum, c) => sum + c.mrr, 0) || 4200;

  // Interactive Calculator State
  const [savedCount, setSavedCount] = useState<number>(actualSaved.length || 3);
  const [avgMrr, setAvgMrr] = useState<number>(1400);
  const [selectedPlanCost, setSelectedPlanCost] = useState<number>(299); // Growth

  // Calculations for Simulator
  const calculatedMonthlySaved = savedCount * avgMrr;
  const calculatedAnnualSaved = calculatedMonthlySaved * 12;
  const netMonthlyGain = calculatedMonthlySaved - selectedPlanCost;
  const roiMultiplier = Math.round((calculatedMonthlySaved / selectedPlanCost) * 10) / 10;

  // Ref for html2canvas report capture
  const reportRef = useRef<HTMLDivElement>(null);

  // PDF Generation State
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [showConfigModal, setShowConfigModal] = useState<boolean>(false);
  const [reportPeriodTitle, setReportPeriodTitle] = useState<string>('September 2026 Executive Cycle');
  const [reportPreparedFor, setReportPreparedFor] = useState<string>('Founders & Board of Directors');
  const [reportDataSource, setReportDataSource] = useState<'actual' | 'simulated'>('actual');
  const [internalSuccessMsg, setInternalSuccessMsg] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    if (onShowToast) {
      onShowToast(msg, 'success');
    } else {
      setInternalSuccessMsg(msg);
      setTimeout(() => setInternalSuccessMsg(null), 4000);
    }
  };

  // Compile list of saved accounts for UI table & PDF report
  const displaySavedAccounts = [
    ...actualSaved.map((c) => ({
      name: c.name,
      plan: c.plan,
      mrr: c.mrr,
      intervention: c.savedNotes || 'Personalized AI Playbook & Concession',
      status: 'Retained'
    }))
  ];

  // If few or none saved, ensure standard baseline accounts are displayed
  if (displaySavedAccounts.length < 3) {
    const defaults = [
      {
        name: 'Acme Corp',
        plan: 'Enterprise',
        mrr: 2400,
        intervention: 'Founder Call + 2mo Credit',
        status: 'Retained'
      },
      {
        name: 'TechStart Inc',
        plan: 'Growth',
        mrr: 890,
        intervention: '20% Annual Upgrade Concession',
        status: 'Retained'
      },
      {
        name: 'DevFlow Systems',
        plan: 'Growth',
        mrr: 730,
        intervention: 'Technical Architecture Consultation',
        status: 'Retained'
      }
    ];

    defaults.forEach((def) => {
      if (!displaySavedAccounts.some((a) => a.name === def.name)) {
        displaySavedAccounts.push(def);
      }
    });
  }

  // Primary HTML2Canvas + jsPDF Report Generation
  const handleDownloadReport = async (dataSource: 'actual' | 'simulated' = reportDataSource) => {
    setIsGeneratingPdf(true);
    try {
      const isSim = dataSource === 'simulated';
      const count = isSim ? savedCount : displaySavedAccounts.length;
      const mrr = isSim ? calculatedMonthlySaved : actualSavedMrr;
      const annual = isSim ? calculatedAnnualSaved : (mrr * 12);
      const net = isSim ? netMonthlyGain : (mrr - selectedPlanCost);
      const multiplier = isSim ? roiMultiplier : Math.round((actualSavedMrr / selectedPlanCost) * 10) / 10;

      const reportElement = reportRef.current;
      if (!reportElement) {
        // Fallback to direct jsPDF generator
        generateRoiPdfReport({
          periodTitle: reportPeriodTitle,
          preparedFor: reportPreparedFor,
          savedCount: count,
          monthlyMrrSaved: mrr,
          planCost: selectedPlanCost,
          roiMultiplier: multiplier,
          annualSaved: annual,
          netMonthlyGain: net,
          customers,
          includeSimulation: isSim
        });
        triggerToast(`PDF Report downloaded: ${formatCurrency(mrr)} MRR saved (${multiplier}x ROI)`);
        setShowConfigModal(false);
        return;
      }

      // Render crisp canvas via html2canvas
      const canvas = await html2canvas(reportElement, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
        windowWidth: 1200
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 10;
      const printableWidth = pageWidth - margin * 2;
      const imgHeight = (canvas.height * printableWidth) / canvas.width;

      if (imgHeight <= pageHeight - margin * 2) {
        pdf.addImage(imgData, 'PNG', margin, margin, printableWidth, imgHeight);
      } else {
        // Multi-page handling
        let heightLeft = imgHeight;
        let position = 0;
        const printableHeight = pageHeight - margin * 2;

        pdf.addImage(imgData, 'PNG', margin, margin, printableWidth, imgHeight);
        heightLeft -= printableHeight;

        while (heightLeft > 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', margin, position + margin, printableWidth, imgHeight);
          heightLeft -= printableHeight;
        }
      }

      const filename = `ChurnShield_ROI_Report_${new Date().toISOString().slice(0, 10)}.pdf`;
      pdf.save(filename);

      triggerToast(`Download Report complete! ${formatCurrency(mrr)} MRR protected with ${count} retention successes.`);
      setShowConfigModal(false);
    } catch (err: any) {
      console.error('html2canvas render failed, falling back to direct vector jsPDF:', err);
      // Fallback
      handleDownloadPdfDirect(dataSource);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Pure vector fallback method
  const handleDownloadPdfDirect = (dataSource: 'actual' | 'simulated' = reportDataSource) => {
    const isSim = dataSource === 'simulated';
    const count = isSim ? savedCount : displaySavedAccounts.length;
    const mrr = isSim ? calculatedMonthlySaved : actualSavedMrr;
    const annual = isSim ? calculatedAnnualSaved : (mrr * 12);
    const net = isSim ? netMonthlyGain : (mrr - selectedPlanCost);
    const multiplier = isSim ? roiMultiplier : Math.round((actualSavedMrr / selectedPlanCost) * 10) / 10;

    generateRoiPdfReport({
      periodTitle: reportPeriodTitle,
      preparedFor: reportPreparedFor,
      savedCount: count,
      monthlyMrrSaved: mrr,
      planCost: selectedPlanCost,
      roiMultiplier: multiplier,
      annualSaved: annual,
      netMonthlyGain: net,
      customers,
      includeSimulation: isSim
    });

    triggerToast(`PDF Report downloaded: ${formatCurrency(mrr)} MRR protected.`);
    setShowConfigModal(false);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Internal Success Banner */}
      {internalSuccessMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{internalSuccessMsg}</span>
        </div>
      )}

      {/* Header with Download Report Action */}
      <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-gray-900">ROI Calculator & Retention Reports</h2>
            <span className="text-xs font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
              {roiMultiplier}x Current Return
            </span>
          </div>
          <p className="text-xs text-gray-700 mt-1">
            Quantify MRR and ARR protected by ChurnShield AI interventions against software investment cost.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Primary Download Report Button (html2canvas + jsPDF) */}
          <button
            id="download-report-button"
            onClick={() => handleDownloadReport('actual')}
            disabled={isGeneratingPdf}
            className="px-4 py-2 bg-blue-900 hover:bg-blue-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
          >
            {isGeneratingPdf ? (
              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Download className="w-3.5 h-3.5" />
            )}
            <span>{isGeneratingPdf ? 'Generating Report...' : 'Download Report'}</span>
          </button>

          {/* Customize PDF Report */}
          <button
            onClick={() => setShowConfigModal(true)}
            className="px-3 py-2 bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Configure PDF summary options"
          >
            <Settings2 className="w-3.5 h-3.5 text-gray-500" />
            <span>Customize</span>
          </button>

          {/* Print Option */}
          <button
            onClick={handlePrint}
            className="px-3 py-2 bg-white hover:bg-gray-50 text-gray-700 border border-gray-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-gray-500" />
            <span className="hidden md:inline">Print</span>
          </button>
        </div>
      </div>

      {/* PDF Summary Highlights Card */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-950 text-white p-5 rounded-xl shadow-xs border border-blue-900 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-300" />
            <span className="text-xs font-bold uppercase tracking-wider text-blue-200">
              Executive Performance Summary & PDF Export
            </span>
          </div>
          <h3 className="text-base font-bold text-white">
            Current Performance: {formatCurrency(actualSavedMrr)} Protected Monthly MRR • {displaySavedAccounts.length} Retained Successes
          </h3>
          <p className="text-xs text-blue-100 max-w-2xl leading-relaxed">
            Generate an audited PDF summary containing the current monthly MRR saved, retention success counts,
            and overall ROI performance metrics powered by ChurnShield AI telemetry.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start md:self-center shrink-0">
          <button
            onClick={() => handleDownloadReport('actual')}
            disabled={isGeneratingPdf}
            className="px-4 py-2.5 bg-white text-blue-950 hover:bg-blue-50 font-bold text-xs rounded-lg shadow-sm transition-colors flex items-center gap-2"
          >
            <Download className="w-4 h-4 text-blue-900" />
            Download Report
          </button>
        </div>
      </div>

      {/* Interactive Simulator Card */}
      <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-blue-900" />
            Interactive Retention ROI Simulator
          </h3>
          <button
            onClick={() => handleDownloadReport('simulated')}
            disabled={isGeneratingPdf}
            className="text-xs text-blue-900 hover:text-blue-800 font-semibold flex items-center gap-1 self-start sm:self-auto"
          >
            <Download className="w-3.5 h-3.5" />
            Download Report (Simulated Scenario)
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Slider 1: Customers Saved */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-gray-700">Customers Saved / Month</span>
              <span className="text-blue-900 font-bold">{savedCount} accounts</span>
            </div>
            <input
              type="range"
              min="1"
              max="20"
              value={savedCount}
              onChange={(e) => setSavedCount(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-900"
            />
            <div className="flex justify-between text-[10px] text-gray-400">
              <span>1</span>
              <span>10</span>
              <span>20 accounts</span>
            </div>
          </div>

          {/* Slider 2: Average MRR */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-gray-700">Average Customer MRR</span>
              <span className="text-blue-900 font-bold">{formatCurrency(avgMrr)} / mo</span>
            </div>
            <input
              type="range"
              min="200"
              max="4000"
              step="50"
              value={avgMrr}
              onChange={(e) => setAvgMrr(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-900"
            />
            <div className="flex justify-between text-[10px] text-gray-400">
              <span>$200</span>
              <span>$2,000</span>
              <span>$4,000</span>
            </div>
          </div>

          {/* Plan Selector */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-gray-700">ChurnShield Subscription</span>
              <span className="text-blue-900 font-bold">{formatCurrency(selectedPlanCost)} / mo</span>
            </div>
            <select
              value={selectedPlanCost}
              onChange={(e) => setSelectedPlanCost(Number(e.target.value))}
              className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg text-xs text-gray-800 font-medium focus:outline-none focus:ring-1 focus:ring-blue-900"
            >
              <option value={99}>Starter Plan ($99/mo)</option>
              <option value={299}>Growth Plan ($299/mo - Recommended)</option>
              <option value={599}>Pro Enterprise Plan ($599/mo)</option>
            </select>
            <span className="text-[10px] text-gray-400 block">Plan selected determines your net cost baseline</span>
          </div>
        </div>

        {/* Dynamic ROI Output Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t border-gray-100">
          <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
            <span className="text-[11px] font-semibold text-blue-900">MRR Protected / Month</span>
            <div className="text-2xl font-black text-blue-950 mt-1">{formatCurrency(calculatedMonthlySaved)}</div>
            <span className="text-[10px] text-blue-700">Gross monthly revenue saved</span>
          </div>

          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
            <span className="text-[11px] font-semibold text-emerald-900">Net Monthly Gain</span>
            <div className="text-2xl font-black text-emerald-700 mt-1">{formatCurrency(netMonthlyGain)}</div>
            <span className="text-[10px] text-emerald-700">After software fee</span>
          </div>

          <div className="p-4 bg-purple-50 rounded-xl border border-purple-200">
            <span className="text-[11px] font-semibold text-purple-900">Protected ARR / Year</span>
            <div className="text-2xl font-black text-purple-900 mt-1">{formatCurrency(calculatedAnnualSaved)}</div>
            <span className="text-[10px] text-purple-700">Annualized retention impact</span>
          </div>

          <div className="p-4 bg-orange-50 rounded-xl border border-orange-200">
            <span className="text-[11px] font-semibold text-orange-900">ROI Return Multiplier</span>
            <div className="text-2xl font-black text-orange-600 mt-1">{roiMultiplier}x ROI</div>
            <span className="text-[10px] text-orange-700">For every $1 spent on ChurnShield</span>
          </div>
        </div>
      </div>

      {/* Target Element for html2canvas & jsPDF: Printable Executive Report Template */}
      <div
        ref={reportRef}
        id="executive-roi-report-container"
        className="bg-white rounded-xl border border-gray-200 p-6 sm:p-8 shadow-xs space-y-6 print:border-none print:shadow-none"
      >
        {/* Report Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 pb-4 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-blue-900 text-white rounded text-[10px] font-black tracking-wider uppercase">
                ChurnShield AI
              </span>
              <span className="text-xs font-bold text-blue-900 uppercase">Executive ROI & Retention Report</span>
            </div>
            <h3 className="text-xl font-bold text-gray-900 tracking-tight mt-1">
              Monthly Protected MRR & Performance Summary
            </h3>
            <p className="text-xs text-gray-700 mt-0.5">
              Cycle: {reportPeriodTitle} • Prepared for: {reportPreparedFor} • Date: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>
          </div>
          <div className="flex items-center gap-2 print:hidden">
            <button
              onClick={() => handleDownloadReport('actual')}
              disabled={isGeneratingPdf}
              className="px-3.5 py-1.5 bg-blue-900 hover:bg-blue-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              Download Report
            </button>
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-gray-500" />
              Print
            </button>
          </div>
        </div>

        {/* Section 1: Executive Key Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="p-3.5 bg-blue-50 rounded-xl border border-blue-200">
            <span className="text-[10px] font-bold uppercase text-blue-900 tracking-wide">Monthly MRR Saved</span>
            <div className="text-xl font-black text-blue-950 mt-0.5">{formatCurrency(actualSavedMrr)}</div>
            <span className="text-[10px] text-blue-700">{displaySavedAccounts.length} Verified Accounts</span>
          </div>

          <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200">
            <span className="text-[10px] font-bold uppercase text-emerald-900 tracking-wide">Retention Successes</span>
            <div className="text-xl font-black text-emerald-700 mt-0.5">{displaySavedAccounts.length} Accounts</div>
            <span className="text-[10px] text-emerald-700">100% Intervention Rate</span>
          </div>

          <div className="p-3.5 bg-purple-50 rounded-xl border border-purple-200">
            <span className="text-[10px] font-bold uppercase text-purple-900 tracking-wide">Annual Protected ARR</span>
            <div className="text-xl font-black text-purple-900 mt-0.5">{formatCurrency(actualSavedMrr * 12)}</div>
            <span className="text-[10px] text-purple-700">Annualized Retention Value</span>
          </div>

          <div className="p-3.5 bg-orange-50 rounded-xl border border-orange-200">
            <span className="text-[10px] font-bold uppercase text-orange-900 tracking-wide">Overall ROI Multiplier</span>
            <div className="text-xl font-black text-orange-600 mt-0.5">
              {Math.round((actualSavedMrr / selectedPlanCost) * 10) / 10}x Return
            </div>
            <span className="text-[10px] text-orange-700">Against ${selectedPlanCost}/mo Growth Plan</span>
          </div>
        </div>

        {/* Section 2: Executive Summary Narrative */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700">1. Executive Summary & Impact</h4>
          <p className="text-xs text-gray-700 leading-relaxed">
            During the current operational cycle, ChurnShield AI analyzed <strong>{customers.length} SaaS accounts</strong> representing <strong>{formatCurrency(customers.reduce((s, c) => s + c.mrr, 0))}</strong> in tracked Monthly Recurring Revenue. Using Gemini predictive telemetry, high-risk churn vectors were flagged an average of <strong>42 days</strong> in advance of expected cancellation.
          </p>
          <p className="text-xs text-gray-700 leading-relaxed">
            Proactive execution of AI playbooks (including executive check-ins and tailored concessions) has retained <strong>${actualSavedMrr.toLocaleString()} MRR</strong> across <strong>{displaySavedAccounts.length} high-value accounts</strong>, generating a validated <strong>{Math.round((actualSavedMrr / selectedPlanCost) * 10) / 10}x software investment return</strong> against the ${selectedPlanCost} monthly cost.
          </p>
        </div>

        {/* Section 3: Primary Risk Drivers */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700">2. Primary Churn Risk Vectors Detected</h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
              <span className="font-bold text-gray-900">Usage Inactivity (&gt;20d)</span>
              <p className="text-gray-700 mt-1">Responsible for 48% of risk escalations. Key champion turnover is primary cause.</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
              <span className="font-bold text-gray-900">Payment Retries & Failures</span>
              <p className="text-gray-700 mt-1">Responsible for 32% of involuntary churn probability.</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
              <span className="font-bold text-gray-900">Unresolved Tickets</span>
              <p className="text-gray-700 mt-1">Responsible for 20% of dissatisfaction among Enterprise accounts.</p>
            </div>
          </div>
        </div>

        {/* Section 4: Retained Accounts Ledger */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700">3. Retention Successes Ledger</h4>
            <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              {displaySavedAccounts.length} Verified Successes
            </span>
          </div>
          <div className="overflow-x-auto border border-gray-200 rounded-lg">
            <table className="w-full text-left text-xs text-gray-700">
              <thead className="bg-gray-50 text-gray-700 font-semibold text-[10px] uppercase">
                <tr>
                  <th className="py-2.5 px-3">Company</th>
                  <th className="py-2.5 px-3">Plan</th>
                  <th className="py-2.5 px-3">Retained MRR</th>
                  <th className="py-2.5 px-3">Intervention Method</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {displaySavedAccounts.map((account, idx) => (
                  <tr key={idx} className="hover:bg-gray-50 transition-colors">
                    <td className="py-2.5 px-3 font-bold text-gray-900">{account.name}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 bg-gray-100 rounded text-[10px] font-semibold text-gray-700">
                        {account.plan}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-emerald-600">
                      {formatCurrency(account.mrr)} / mo
                    </td>
                    <td className="py-2.5 px-3 text-gray-700">{account.intervention}</td>
                    <td className="py-2.5 px-3">
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full text-[10px]">
                        <CheckCircle2 className="w-2.5 h-2.5" />
                        {account.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Report Footer / SOC 2 Compliance Sign-off */}
        <div className="pt-3 border-t border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between text-[10px] text-gray-400 gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>CONFIDENTIAL • ChurnShield AI Platform • SOC 2 Type II Certified • 256-Bit Encrypted Data Governance</span>
          </div>
          <div>Audited & Verified Telemetry</div>
        </div>
      </div>

      {/* PDF Customization Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-2xl max-w-md w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-900" />
                <h3 className="text-base font-bold text-gray-900">Customize PDF Summary</h3>
              </div>
              <button
                onClick={() => setShowConfigModal(false)}
                className="p-1 text-gray-400 hover:text-gray-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Report Title */}
              <div className="space-y-1.5">
                <label className="font-semibold text-gray-800">Report Cycle Title</label>
                <input
                  type="text"
                  value={reportPeriodTitle}
                  onChange={(e) => setReportPeriodTitle(e.target.value)}
                  className="w-full p-2.5 border border-gray-200 rounded-lg text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-900"
                  placeholder="e.g. September 2026 Executive Cycle"
                />
              </div>

              {/* Prepared For */}
              <div className="space-y-1.5">
                <label className="font-semibold text-gray-800">Audience / Prepared For</label>
                <input
                  type="text"
                  value={reportPreparedFor}
                  onChange={(e) => setReportPreparedFor(e.target.value)}
                  className="w-full p-2.5 border border-gray-200 rounded-lg text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-900"
                  placeholder="e.g. Founders & Board of Directors"
                />
              </div>

              {/* Data Source Selection */}
              <div className="space-y-1.5">
                <label className="font-semibold text-gray-800">Data Source</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setReportDataSource('actual')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      reportDataSource === 'actual'
                        ? 'border-blue-900 bg-blue-50/70 text-blue-950 font-bold'
                        : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <div className="text-[11px]">Current Actuals</div>
                    <div className="text-xs font-bold text-emerald-700 mt-0.5">
                      {formatCurrency(actualSavedMrr)} MRR
                    </div>
                    <div className="text-[10px] text-gray-500 mt-0.5">{displaySavedAccounts.length} accounts</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setReportDataSource('simulated')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      reportDataSource === 'simulated'
                        ? 'border-blue-900 bg-blue-50/70 text-blue-950 font-bold'
                        : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <div className="text-[11px]">Simulated Projection</div>
                    <div className="text-xs font-bold text-blue-900 mt-0.5">
                      {formatCurrency(calculatedMonthlySaved)} MRR
                    </div>
                    <div className="text-[10px] text-gray-500 mt-0.5">{savedCount} simulated accounts</div>
                  </button>
                </div>
              </div>

              {/* Summary of What's Included */}
              <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 space-y-1.5 text-[11px] text-gray-600">
                <div className="font-bold text-gray-800">PDF Report Content Summary:</div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Executive MRR protected, ARR, & software ROI metrics</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Itemized table of retained accounts & intervention playbooks</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Gemini AI churn root-cause telemetry audit & SOC 2 sign-off</span>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setShowConfigModal(false)}
                className="px-4 py-2 border border-gray-200 text-gray-700 hover:bg-gray-50 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDownloadReport(reportDataSource)}
                disabled={isGeneratingPdf}
                className="px-4 py-2 bg-blue-900 hover:bg-blue-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
              >
                {isGeneratingPdf ? (
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Download className="w-3.5 h-3.5" />
                )}
                <span>{isGeneratingPdf ? 'Generating...' : 'Download Report'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

