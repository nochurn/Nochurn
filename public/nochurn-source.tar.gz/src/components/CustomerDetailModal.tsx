import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Copy,
  Check,
  Calendar,
  DollarSign,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  Clock,
  Send,
  LifeBuoy,
  CreditCard,
  UserCheck,
  MessageSquare,
  FileText,
  Activity,
  Award
} from 'lucide-react';
import { Customer } from '../types';
import { formatCurrency, getRiskColorClass } from '../utils/formatters';
import { HealthPillarsCard } from './HealthPillarsCard';

interface CustomerDetailModalProps {
  customer: Customer | null;
  onClose: () => void;
  onRunAiPredict: (id: string) => Promise<void>;
  onRunAiRecommend: (id: string) => Promise<void>;
  onMarkSaved: (id: string, notes?: string) => Promise<void>;
  isAiLoading: boolean;
}

export const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({
  customer,
  onClose,
  onRunAiPredict,
  onRunAiRecommend,
  onMarkSaved,
  isAiLoading
}) => {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'playbook' | 'history'>('overview');
  const [savedNotes, setSavedNotes] = useState('');
  const [showSaveConfirm, setShowSaveConfirm] = useState(false);

  if (!customer) return null;

  const riskClasses = getRiskColorClass(customer.riskCategory);

  const handleCopyEmail = () => {
    if (customer.retentionRecommendation?.emailScript) {
      navigator.clipboard.writeText(customer.retentionRecommendation.emailScript);
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between bg-gray-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-900 text-white font-bold flex items-center justify-center text-sm shadow-xs">
              {customer.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-gray-900 leading-none">{customer.name}</h3>
                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${riskClasses.badge}`}>
                  Risk Score: {customer.riskScore} • {customer.riskCategory}
                </span>
                {customer.status === 'saved' && (
                  <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    Saved Customer
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-700 mt-1 flex items-center gap-3">
                <span>{customer.email}</span>
                <span>•</span>
                <span className="font-medium text-gray-700">{customer.companyDomain}</span>
                <span>•</span>
                <span className="text-blue-900 font-semibold">{customer.plan} Tier</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors focus:outline-none"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 border-b border-gray-200 bg-white flex items-center gap-6 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'overview'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            <Activity className="w-4 h-4" />
            AI Risk Breakdown
          </button>
          <button
            onClick={() => setActiveTab('playbook')}
            className={`py-3 border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'playbook'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            <Sparkles className="w-4 h-4 text-orange-500" />
            Gemini Retention Playbook & Email Script
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-3 border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'history'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            <Calendar className="w-4 h-4" />
            Historical Telemetry & Invoices
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-gray-50 p-3 rounded-xl border border-gray-200/80">
            <div>
              <span className="text-[11px] text-gray-700 font-medium">Monthly Recurring (MRR)</span>
              <div className="text-base font-bold text-gray-900 mt-0.5">{formatCurrency(customer.mrr)}</div>
              <span className="text-[10px] text-gray-700">LTV: {formatCurrency(customer.ltv)}</span>
            </div>

            <div>
              <span className="text-[11px] text-gray-700 font-medium">Days Since Login</span>
              <div className={`text-base font-bold mt-0.5 ${customer.lastLoginDays > 14 ? 'text-red-600' : 'text-gray-900'}`}>
                {customer.lastLoginDays} days ago
              </div>
              <span className="text-[10px] text-gray-700">Since {customer.customerSince}</span>
            </div>

            <div>
              <span className="text-[11px] text-gray-700 font-medium">Usage Trend (30d)</span>
              <div className="flex items-center gap-1 mt-0.5">
                {customer.usageTrendPercentage < 0 ? (
                  <TrendingDown className="w-4 h-4 text-red-500" />
                ) : (
                  <TrendingUp className="w-4 h-4 text-emerald-500" />
                )}
                <span className={`text-base font-bold ${customer.usageTrendPercentage < 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                  {customer.usageTrendPercentage}%
                </span>
              </div>
              <span className="text-[10px] text-gray-700">Email Open: {customer.emailOpenRate}%</span>
            </div>

            <div>
              <span className="text-[11px] text-gray-700 font-medium">Payment & Tickets</span>
              <div className="text-base font-bold text-gray-900 mt-0.5 flex items-center gap-1.5">
                <span className={`text-xs px-1.5 py-0.5 rounded font-semibold ${
                  customer.paymentStatus === 'Current' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                }`}>
                  {customer.paymentStatus}
                </span>
              </div>
              <span className="text-[10px] text-gray-700">{customer.openTicketsCount} Open Tickets</span>
            </div>
          </div>

          {/* TAB 1: OVERVIEW & GEMINI RISK BREAKDOWN */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* 5-Pillar Churn Health Signals */}
              <HealthPillarsCard customer={customer} />

              {/* Predicted Churn Probabilities */}
              <div className="p-4 rounded-xl border border-gray-200 bg-white">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700">
                      Gemini Churn Probability Horizon
                    </h4>
                    <p className="text-xs text-gray-700">Predicted likelihood of churn if no intervention is made</p>
                  </div>
                  <button
                    onClick={() => onRunAiPredict(customer.id)}
                    disabled={isAiLoading}
                    className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-blue-200" />
                    {isAiLoading ? 'Analyzing...' : 'Re-Run Gemini Analysis'}
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <span className="text-xs font-semibold text-gray-600">Next 30 Days</span>
                    <div className="text-xl font-bold text-gray-900 mt-1">
                      {customer.churnProbability?.day30 ?? Math.round(customer.riskScore * 0.85)}%
                    </div>
                    <div className="w-full bg-gray-200 h-1.5 rounded-full mt-2 overflow-hidden">
                      <div
                        className="bg-red-500 h-full rounded-full transition-all"
                        style={{ width: `${customer.churnProbability?.day30 ?? customer.riskScore}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <span className="text-xs font-semibold text-gray-600">Next 60 Days</span>
                    <div className="text-xl font-bold text-gray-900 mt-1">
                      {customer.churnProbability?.day60 ?? Math.round(customer.riskScore * 0.95)}%
                    </div>
                    <div className="w-full bg-gray-200 h-1.5 rounded-full mt-2 overflow-hidden">
                      <div
                        className="bg-red-500 h-full rounded-full transition-all"
                        style={{ width: `${customer.churnProbability?.day60 ?? customer.riskScore}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <span className="text-xs font-semibold text-gray-600">Next 90 Days</span>
                    <div className="text-xl font-bold text-gray-900 mt-1">
                      {customer.churnProbability?.day90 ?? Math.min(99, customer.riskScore + 6)}%
                    </div>
                    <div className="w-full bg-gray-200 h-1.5 rounded-full mt-2 overflow-hidden">
                      <div
                        className="bg-red-500 h-full rounded-full transition-all"
                        style={{ width: `${customer.churnProbability?.day90 ?? customer.riskScore}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Top 3 Risk Factors Breakdown */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700">
                  Top 3 Contributing Churn Factors (with Risk Point Weights)
                </h4>

                <div className="space-y-2.5">
                  {customer.topFactors?.map((factor, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-gray-50/80 rounded-xl border border-gray-200 flex items-start gap-3"
                    >
                      <div className="w-7 h-7 rounded-lg bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        +{factor.points}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-gray-900">{factor.factor}</span>
                          <span className="text-[10px] uppercase font-semibold text-gray-700 bg-white px-2 py-0.5 rounded border border-gray-200">
                            {factor.category}
                          </span>
                        </div>
                        <p className="text-xs text-gray-700 mt-1 leading-relaxed">
                          {factor.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Action Summary */}
              <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-200/80 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900">
                    Recommended Retention Playbook
                  </span>
                  <p className="text-sm font-bold text-gray-900 mt-0.5">
                    {customer.recommendedAction || 'Executive Outreach & Value Review'}
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('playbook')}
                  className="px-3.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors"
                >
                  Open Email Script →
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: RETENTION PLAYBOOK & COPY-PASTE EMAIL */}
          {activeTab === 'playbook' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700">
                    Gemini AI Personalized Retention Script
                  </h4>
                  <p className="text-xs text-gray-700">
                    Tuned for high recovery probability based on customer telemetry and pain points
                  </p>
                </div>
                <button
                  onClick={() => onRunAiRecommend(customer.id)}
                  disabled={isAiLoading}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors disabled:opacity-50"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-200" />
                  {isAiLoading ? 'Generating...' : 'Regenerate Email with Gemini'}
                </button>
              </div>

              {/* Playbook Metrics Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-center">
                  <span className="text-[11px] font-medium text-emerald-800">Estimated Recovery Rate</span>
                  <div className="text-xl font-bold text-emerald-700 mt-0.5">
                    {customer.retentionRecommendation?.recoveryProbability ?? 38}%
                  </div>
                  <span className="text-[10px] text-emerald-700">Typical benchmark for SaaS interventions</span>
                </div>

                <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-center">
                  <span className="text-[11px] font-medium text-blue-800">Estimated Effort</span>
                  <div className="text-xl font-bold text-blue-900 mt-0.5">
                    {customer.retentionRecommendation?.effortMinutes ?? 25} min
                  </div>
                  <span className="text-[10px] text-blue-700">Time needed for outreach & setup</span>
                </div>

                <div className="p-3 bg-purple-50 rounded-xl border border-purple-200 text-center">
                  <span className="text-[11px] font-medium text-purple-800">Recommended Channel</span>
                  <div className="text-xl font-bold text-purple-900 mt-0.5">
                    {customer.retentionRecommendation?.suggestedChannel || 'Email'}
                  </div>
                  <span className="text-[10px] text-purple-700">Highest conversion medium</span>
                </div>
              </div>

              {/* Personalized Email Box */}
              <div className="rounded-xl border border-gray-200 overflow-hidden bg-white shadow-xs">
                <div className="bg-gray-50 px-4 py-2.5 border-b border-gray-200 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-semibold text-gray-700">
                    <FileText className="w-4 h-4 text-blue-900" />
                    <span>Copy-Paste Ready Email Script</span>
                  </div>

                  <button
                    onClick={handleCopyEmail}
                    className="px-3 py-1 bg-white hover:bg-gray-100 border border-gray-200 text-gray-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    {copiedEmail ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700">Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-gray-500" />
                        <span>Copy Script</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="p-4 bg-gray-50/40 text-xs font-mono text-gray-800 whitespace-pre-wrap leading-relaxed">
                  {customer.retentionRecommendation?.emailScript || (
                    `Subject: Urgent check-in regarding ${customer.name}'s account\n\nHi ${customer.name.split(' ')[0]},\n\nI noticed your team has faced some friction recently and wanted to personally step in. Can we connect today for 10 minutes?\n\nBest,\nAlex Vance\nFounder & CEO, ChurnShield AI`
                  )}
                </div>
              </div>

              {/* Concession / Offer */}
              {customer.retentionRecommendation?.offerDiscount && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center gap-3">
                  <Award className="w-5 h-5 text-amber-600 shrink-0" />
                  <div className="text-xs">
                    <span className="font-bold text-amber-900">Recommended Concession / Incentive:</span>{' '}
                    <span className="text-amber-800">{customer.retentionRecommendation.offerDiscount}</span>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-gray-900">Did you execute this retention playbook?</h5>
                    <p className="text-[11px] text-gray-700">
                      Marking as saved will record MRR retained and increase your dashboard ROI counter.
                    </p>
                  </div>

                  {customer.status !== 'saved' ? (
                    <button
                      onClick={() => setShowSaveConfirm(true)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <UserCheck className="w-4 h-4" />
                      Mark as Saved & Retained (+${customer.mrr} MRR)
                    </button>
                  ) : (
                    <span className="px-3 py-1.5 bg-emerald-100 text-emerald-800 rounded-lg text-xs font-semibold flex items-center gap-1.5">
                      <Check className="w-4 h-4 text-emerald-600" />
                      Customer Retained
                    </span>
                  )}
                </div>

                {showSaveConfirm && (
                  <div className="pt-3 border-t border-gray-200 space-y-2">
                    <input
                      type="text"
                      placeholder="Add brief note (e.g., 'Offered 20% discount on renewal, founder approved call')"
                      value={savedNotes}
                      onChange={(e) => setSavedNotes(e.target.value)}
                      className="w-full text-xs p-2 border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setShowSaveConfirm(false)}
                        className="px-3 py-1 text-xs text-gray-500 hover:text-gray-700"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => {
                          onMarkSaved(customer.id, savedNotes);
                          setShowSaveConfirm(false);
                        }}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg"
                      >
                        Confirm Save
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: HISTORICAL TELEMETRY & CHARTS */}
          {activeTab === 'history' && (
            <div className="space-y-6">
              {/* Risk Score 6-Month Trend Chart (SVG) */}
              <div className="p-4 rounded-xl border border-gray-200 bg-white">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700">
                    6-Month Risk Score Migration Trend
                  </h4>
                  <span className="text-[11px] text-gray-700">Current: {customer.riskScore}/100</span>
                </div>

                <div className="h-44 w-full relative">
                  <svg className="w-full h-full" viewBox="0 0 500 160" preserveAspectRatio="none">
                    {/* Background threshold bands */}
                    <rect x="0" y="0" width="500" height="24" fill="#fee2e2" opacity="0.4" />
                    <rect x="0" y="24" width="500" height="40" fill="#ffedd5" opacity="0.4" />
                    <rect x="0" y="64" width="500" height="48" fill="#fef3c7" opacity="0.4" />
                    <rect x="0" y="112" width="500" height="48" fill="#d1fae5" opacity="0.4" />

                    {/* Trend Line */}
                    {customer.riskTrend && customer.riskTrend.length > 0 && (
                      <polyline
                        fill="none"
                        stroke="#1e3a8a"
                        strokeWidth="3"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        points={customer.riskTrend
                          .map((pt, i) => {
                            const x = (i / (customer.riskTrend.length - 1)) * 480 + 10;
                            const y = 150 - (pt.score / 100) * 140;
                            return `${x},${y}`;
                          })
                          .join(' ')}
                      />
                    )}

                    {/* Data Points */}
                    {customer.riskTrend &&
                      customer.riskTrend.map((pt, i) => {
                        const x = (i / (customer.riskTrend.length - 1)) * 480 + 10;
                        const y = 150 - (pt.score / 100) * 140;
                        return (
                          <g key={i}>
                            <circle cx={x} cy={y} r="4.5" fill="#1e3a8a" stroke="#fff" strokeWidth="2" />
                            <text x={x} y={y - 8} fontSize="9" fontWeight="bold" textAnchor="middle" fill="#111827">
                              {pt.score}
                            </text>
                            <text x={x} y="156" fontSize="9" textAnchor="middle" fill="#6b7280">
                              {pt.month}
                            </text>
                          </g>
                        );
                      })}
                  </svg>
                </div>
              </div>

              {/* Login Sessions & Support Tickets Columns */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Login History */}
                <div className="p-4 rounded-xl border border-gray-200 bg-white">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 mb-2 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-gray-500" />
                    Weekly Login Sessions (Mixpanel)
                  </h4>
                  <div className="space-y-2">
                    {customer.loginHistory?.map((lh, i) => (
                      <div key={i} className="flex items-center justify-between text-xs p-2 bg-gray-50 rounded-lg">
                        <span className="font-semibold text-gray-700">{lh.week}</span>
                        <span className="text-gray-600">{lh.activeUsers} active seats</span>
                        <span className="font-medium text-gray-900">{lh.sessionsCount} sessions</span>
                        <span className="text-gray-500">{lh.durationMinutes}m duration</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Support Tickets */}
                <div className="p-4 rounded-xl border border-gray-200 bg-white">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 mb-2 flex items-center gap-1.5">
                    <LifeBuoy className="w-3.5 h-3.5 text-gray-500" />
                    Intercom Support Tickets
                  </h4>
                  {customer.supportTickets?.length === 0 ? (
                    <div className="p-4 text-center text-xs text-gray-700">No open support tickets.</div>
                  ) : (
                    <div className="space-y-2">
                      {customer.supportTickets?.map((tck) => (
                        <div key={tck.id} className="p-2.5 bg-gray-50 rounded-lg text-xs space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-gray-900">{tck.id}</span>
                            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              tck.priority === 'Urgent' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {tck.priority} Priority
                            </span>
                          </div>
                          <p className="text-gray-700 leading-tight">{tck.subject}</p>
                          <div className="flex items-center justify-between text-[10px] text-gray-700 pt-1">
                            <span>Status: {tck.status}</span>
                            <span>{tck.createdAt}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Payments History */}
              <div className="p-4 rounded-xl border border-gray-200 bg-white">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 mb-2 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-gray-500" />
                  Razorpay Payment Invoices
                </h4>
                <div className="divide-y divide-gray-100 text-xs">
                  {customer.paymentHistory?.map((pmt) => (
                    <div key={pmt.id} className="py-2 flex items-center justify-between">
                      <div>
                        <span className="font-semibold text-gray-900">{pmt.invoiceId}</span>
                        <span className="text-gray-700 ml-2">Invoice {pmt.id}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-gray-900">{formatCurrency(pmt.amount)}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          pmt.status === 'Succeeded' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {pmt.status}
                        </span>
                        <span className="text-gray-700 text-[11px]">{pmt.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-gray-200 bg-gray-50/70 flex items-center justify-between">
          <div className="text-xs text-gray-700">
            Last AI analysis: {new Date(customer.lastAnalyzedAt).toLocaleString()}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-gray-100 border border-gray-200 text-gray-700 rounded-lg text-xs font-semibold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
