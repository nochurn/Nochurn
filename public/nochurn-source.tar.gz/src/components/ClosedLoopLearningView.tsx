import React, { useState } from 'react';
import { Customer, CohortMonthRecord, ChurnReasonStats } from '../types';
import { INITIAL_COHORTS, INITIAL_CHURN_REASONS } from '../utils/retentionEngine';
import { formatCurrency, formatNumber } from '../utils/formatters';
import {
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  Award,
  Sparkles,
  Download,
  Filter,
  CheckCircle2,
  XCircle,
  BarChart3,
  Layers,
  ArrowUpRight,
  HelpCircle,
  Lightbulb
} from 'lucide-react';

interface ClosedLoopLearningViewProps {
  customers: Customer[];
  cohorts?: CohortMonthRecord[];
  churnReasons?: ChurnReasonStats[];
  savedMrrTotal?: number;
}

export const ClosedLoopLearningView: React.FC<ClosedLoopLearningViewProps> = ({
  customers,
  cohorts = INITIAL_COHORTS,
  churnReasons = INITIAL_CHURN_REASONS,
  savedMrrTotal = 26850
}) => {
  const [selectedCohortMonth, setSelectedCohortMonth] = useState<string>('all');

  // Calculate total saved across cohorts
  const totalRescued = cohorts.reduce((acc, c) => acc + c.rescuedCount, 0);
  const totalChurned = cohorts.reduce((acc, c) => acc + c.churnedCount, 0);
  const overallWinRate = Math.round((totalRescued / (totalRescued + totalChurned)) * 100);

  const handleExportOutcomes = () => {
    const csvContent =
      'cohort_month,high_risk_count,actioned_count,rescued_count,churned_count,saved_mrr,win_rate_percent\n' +
      cohorts
        .map(
          (c) =>
            `"${c.month}",${c.highRiskCount},${c.actionedCount},${c.rescuedCount},${c.churnedCount},${c.savedMrr},${c.winRate}`
        )
        .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'churnshield_retention_cohorts.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner: Closed-Loop AI OS */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-emerald-800">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-emerald-700/60 text-emerald-200 border border-emerald-400/30 text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
                Closed-Loop Learning System
              </span>
              <span className="text-xs text-emerald-200 font-medium">Auto-Tuning Active</span>
            </div>
            <h1 className="text-2xl font-black tracking-tight">
              Retention Outcomes & Churn Attribution
            </h1>
            <p className="text-xs text-emerald-100/90 max-w-2xl leading-relaxed">
              Don't just predict churn—measure exactly what works. Every rescued account logs the successful playbook; every churned account captures root-cause feedback that re-calibrates risk weights and improves future AI recommendations.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-emerald-950/70 p-3 rounded-xl border border-emerald-700/40">
            <div className="text-center p-2">
              <span className="text-[10px] uppercase font-bold text-emerald-300 block">Total MRR Protected</span>
              <span className="text-xl font-black text-emerald-300">+{formatCurrency(savedMrrTotal)}</span>
            </div>
            <div className="text-center p-2 border-l border-emerald-800">
              <span className="text-[10px] uppercase font-bold text-emerald-300 block">Accounts Rescued</span>
              <span className="text-xl font-black text-white">{totalRescued}</span>
            </div>
            <div className="text-center p-2 border-l border-emerald-800">
              <span className="text-[10px] uppercase font-bold text-emerald-300 block">Intervention Win Rate</span>
              <span className="text-xl font-black text-amber-300">{overallWinRate}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Cohort Matrix & Root Cause Attribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Rescued vs. Churned Cohort Matrix */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-gray-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <div>
              <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-600" />
                Rescued vs. Churned Cohort Performance
              </h3>
              <p className="text-xs text-gray-500">
                Track whether early intervention directly improves customer survival over 30/60/90 days.
              </p>
            </div>
            <button
              onClick={handleExportOutcomes}
              className="px-3 py-1.5 text-xs font-semibold text-gray-700 hover:text-gray-900 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-gray-500" />
              <span>Export Cohort CSV</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-gray-50 text-gray-600 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Cohort Month</th>
                  <th className="py-2.5 px-3 text-center">At-Risk</th>
                  <th className="py-2.5 px-3 text-center">Actioned</th>
                  <th className="py-2.5 px-3 text-center">Rescued</th>
                  <th className="py-2.5 px-3 text-center">Lost</th>
                  <th className="py-2.5 px-3 text-right">Protected MRR</th>
                  <th className="py-2.5 px-3 text-right">Win Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {cohorts.map((c, idx) => (
                  <tr key={idx} className="hover:bg-gray-50/70 transition-colors">
                    <td className="py-3 px-3 font-bold text-gray-900">
                      {c.month}
                    </td>
                    <td className="py-3 px-3 text-center font-semibold text-gray-700">
                      {c.highRiskCount}
                    </td>
                    <td className="py-3 px-3 text-center font-semibold text-blue-700">
                      {c.actionedCount}
                    </td>
                    <td className="py-3 px-3 text-center font-bold text-emerald-700 bg-emerald-50/40">
                      {c.rescuedCount}
                    </td>
                    <td className="py-3 px-3 text-center font-semibold text-red-600">
                      {c.churnedCount}
                    </td>
                    <td className="py-3 px-3 text-right font-black text-emerald-700">
                      +{formatCurrency(c.savedMrr)}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <span className="inline-block px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-900">
                        {c.winRate}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-blue-50/60 border border-blue-200/70 rounded-xl p-3 text-xs text-blue-900 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
            <div>
              <strong>Key Cohort Insight:</strong> Outreach executed within <strong>24 hours</strong> of risk detection achieves a <strong>73.6% retention win-rate</strong> compared to only 28.4% when delayed past 7 days.
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Why Customers Churn Root Cause Attribution */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-gray-200 shadow-xs p-5 space-y-4">
          <div className="border-b border-gray-100 pb-3">
            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-red-600" />
              Root Cause Churn Attribution
            </h3>
            <p className="text-xs text-gray-500">
              Attribution breakdown of why cancellations occurred & recommended preventative product fixes.
            </p>
          </div>

          <div className="space-y-3.5">
            {churnReasons.map((reason, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-3 border border-gray-200/80 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-gray-900">{reason.label}</span>
                  <span className="font-black text-red-600">{reason.percentage}% ({reason.count} accts)</span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-red-500 rounded-full"
                    style={{ width: `${reason.percentage}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-gray-500">
                  <span>MRR Lost: <strong className="text-gray-900">{formatCurrency(reason.mrrLost)}</strong></span>
                  <span className="text-[10px] font-semibold text-blue-700">Preventative Fix:</span>
                </div>

                {/* Preventative Fix text */}
                <div className="bg-white p-2 rounded-lg border border-gray-200 text-[11px] text-gray-700 flex items-start gap-1.5">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                  <span>{reason.preventiveFix}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Prompt Tuning Feedback Loop Card */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">
              How Closed-Loop Feedback Trains the AI Recommendation Engine
            </h3>
            <p className="text-xs text-gray-500">
              Real-time synchronization between CS outcomes and retention playbooks
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-200/80 space-y-1.5">
            <span className="font-bold text-blue-950 uppercase tracking-wider text-[10px] block">
              1. Outcome Ingestion
            </span>
            <p className="text-gray-700">
              When you mark an account as <strong>"Recovered"</strong> (e.g., QuickPay Technologies), ChurnShield records the intervention type ("Founder Executive Call") and customer response.
            </p>
          </div>

          <div className="p-3.5 bg-indigo-50/50 rounded-xl border border-indigo-200/80 space-y-1.5">
            <span className="font-bold text-indigo-950 uppercase tracking-wider text-[10px] block">
              2. Weight Calibration
            </span>
            <p className="text-gray-700">
              If accounts with unresolved webhook tickets consistently churn when unattended, the system dynamically boosts the <strong>Support Health Pillar weight from 15% to 22%</strong>.
            </p>
          </div>

          <div className="p-3.5 bg-emerald-50/50 rounded-xl border border-emerald-200/80 space-y-1.5">
            <span className="font-bold text-emerald-950 uppercase tracking-wider text-[10px] block">
              3. Script Personalization
            </span>
            <p className="text-gray-700">
              Future Gemini email drafts automatically adopt the exact tone and concessions that previously achieved verified retention, eliminating guesswork for junior CSMs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
