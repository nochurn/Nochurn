import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Footer } from './components/Footer';
import { DashboardView } from './components/DashboardView';
import { CustomerTableView } from './components/CustomerTableView';
import { RetentionPlaybooksView } from './components/RetentionPlaybooksView';
import { DataIntegrationView } from './components/DataIntegrationView';
import { AnalyticsView } from './components/AnalyticsView';
import { RoiCalculatorView } from './components/RoiCalculatorView';
import { DailyAlertsView } from './components/DailyAlertsView';
import { PricingView } from './components/PricingView';
import { SecurityView } from './components/SecurityView';
import { BillingSettingsView } from './components/BillingSettingsView';
import { AdminBillingPlansView } from './components/AdminBillingPlansView';
import { AdminDatabaseTestView } from './components/AdminDatabaseTestView';
import { CustomerDetailModal } from './components/CustomerDetailModal';
import { SuccessView } from './components/SuccessView';
import { ActionQueueView } from './components/ActionQueueView';
import { ClosedLoopLearningView } from './components/ClosedLoopLearningView';
import { RoadmapMetricsView } from './components/RoadmapMetricsView';
import { OnboardingModal } from './components/OnboardingModal';
import { ChurnReasonType } from './types';

// Auth Components
import { LoginView } from './components/auth/LoginView';
import { SignupView } from './components/auth/SignupView';
import { TwoFactorPromptView } from './components/auth/TwoFactorPromptView';
import { ForgotPasswordView } from './components/auth/ForgotPasswordView';
import { ResetPasswordView } from './components/auth/ResetPasswordView';
import { BillingVerifyView } from './components/BillingVerifyView';

// Legal & Security Pages
import { SecurityTermsView } from './components/legal/SecurityTermsView';
import { PrivacyPolicyView } from './components/legal/PrivacyPolicyView';
import { LegalPagesView } from './components/legal/LegalPagesView';

import { apiService } from './services/api';
import { authService } from './services/authService';
import { Customer, IntegrationStatus, DailyAlert, UserProfile } from './types';
import { Sparkles, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';

// Helper to parse hash and query parameters
function parseRouteHash(hashString: string): { view: string; params: Record<string, string> } {
  const params: Record<string, string> = {};

  // Check window.location.search first (for /signup?plan=growth&price=299)
  if (typeof window !== 'undefined' && window.location.search) {
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.forEach((val, key) => {
      params[key] = val;
    });
  }

  // Also check pathname (for /pricing, /signup, /settings/billing, /success)
  let pathnameView = '';
  if (typeof window !== 'undefined' && window.location.pathname) {
    const rawPath = window.location.pathname.replace(/^\/+/, '').replace(/\/+$/, '');
    if (rawPath && rawPath !== 'index.html') {
      pathnameView = rawPath;
    }
  }

  const clean = hashString.replace(/^#\/?/, '');
  const [viewPart, queryPart] = clean.split('?');
  if (queryPart) {
    const searchParams = new URLSearchParams(queryPart);
    searchParams.forEach((val, key) => {
      params[key] = val;
    });
  }
  let resolvedView = viewPart || pathnameView || 'dashboard';
  if (resolvedView === 'billing/verify' || resolvedView === 'billing-verify') {
    resolvedView = 'billing_verify';
  }
  return { view: resolvedView, params };
}

export default function App() {
  const initialRoute = parseRouteHash(window.location.hash);
  // Navigation & View state
  const [activeView, setActiveView] = useState<string>(initialRoute.view);
  const [routeParams, setRouteParams] = useState<Record<string, string>>(initialRoute.params);

  // Auth state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => authService.getCurrentUser());
  const [userAwaiting2FA, setUserAwaiting2FA] = useState<UserProfile | null>(null);
  const [authInitialized, setAuthInitialized] = useState<boolean>(false);

  // Customer Data & Pagination state
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [allCustomers, setAllCustomers] = useState<Customer[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [limit, setLimit] = useState<number>(25);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Search & Filter state
  const [searchValue, setSearchValue] = useState<string>('');
  const [filters, setFilters] = useState({
    riskLevel: 'all',
    mrrRange: 'all',
    plan: 'all',
    factor: 'all'
  });
  const [sortBy, setSortBy] = useState<string>('riskScore');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Selected customer for modal
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);

  // Secondary data
  const [integrations, setIntegrations] = useState<IntegrationStatus[]>([]);
  const [alerts, setAlerts] = useState<DailyAlert[]>([]);
  const [geminiReady, setGeminiReady] = useState<boolean>(true);

  // Retention OS State: Onboarding & Demo banner
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);
  const [dismissDemoBanner, setDismissDemoBanner] = useState<boolean>(false);

  // Operation states
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [isBatchAnalyzing, setIsBatchAnalyzing] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = useCallback((text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  }, []);

  // Synchronize hash with activeView
  const handleNavigate = useCallback((view: string, params?: Record<string, string>) => {
    const normalizedView = view === 'billing/verify' || view === 'billing-verify' ? 'billing_verify' : view;
    setActiveView(normalizedView);
    setRouteParams(params || {});
    const query = params && Object.keys(params).length > 0
      ? `?${new URLSearchParams(params).toString()}`
      : '';
    window.location.hash = `#${view}${query}`;
    try {
      window.history.pushState(null, '', `/${view}${query}`);
    } catch (e) {
      // Ignored in sandboxed iframes
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // Handle URL hash changes from browser back/forward
  useEffect(() => {
    const handleHashChange = () => {
      const { view, params } = parseRouteHash(window.location.hash);
      setActiveView(view);
      setRouteParams(params);
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Subscribe to authService state changes & handle initial session load
  useEffect(() => {
    const unsub = authService.subscribe((user) => {
      setCurrentUser(user);
      setAuthInitialized(true);
    });
    // Initial sync
    setCurrentUser(authService.getCurrentUser());
    setAuthInitialized(true);

    return () => unsub();
  }, []);

  // Public views that do not require an active authenticated subscription
  const PUBLIC_VIEWS = new Set([
    'login',
    'signup',
    '2fa-prompt',
    'forgot-password',
    'reset-password',
    'pricing',
    'security',
    'privacy',
    'terms',
    'dpa',
    'cookies',
    'acceptable-use',
    'contact',
    'help',
    'success',
    'payment-success'
  ]);

  // Route protection and post-auth redirect enforcement
  useEffect(() => {
    if (!authInitialized) return;

    const isPublic = PUBLIC_VIEWS.has(activeView);

    // 1. Unauthenticated users trying to access protected views
    if (!isPublic && !currentUser) {
      handleNavigate('login');
      return;
    }

    // 2. Billing verification route handling
    if (activeView === 'billing_verify') {
      if (!currentUser) {
        handleNavigate('login');
        return;
      }
      if (currentUser.billingStatus === 'trialing' || currentUser.billingStatus === 'active') {
        handleNavigate('dashboard');
        return;
      }
      return;
    }

    // 3. Authenticated users accessing protected app routes (dashboard, customers, etc.)
    if (!isPublic) {
      const hasPendingPlan = authService.hasPendingPlan() || currentUser?.paymentStatus === 'pending';
      const isTrialingOrActive = currentUser?.billingStatus === 'trialing' || currentUser?.billingStatus === 'active';

      if (hasPendingPlan && !isTrialingOrActive) {
        handleNavigate('billing_verify');
        return;
      }

      if (!isTrialingOrActive) {
        handleNavigate('pricing');
        return;
      }
    }
  }, [authInitialized, currentUser, activeView, handleNavigate]);

  // Fetch paginated customers
  const loadCustomers = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await apiService.fetchCustomers({
        page,
        limit,
        search: searchValue,
        riskLevel: filters.riskLevel,
        mrrRange: filters.mrrRange,
        plan: filters.plan,
        factor: filters.factor,
        sortBy,
        sortOrder
      });
      setCustomers(res.customers);
      setTotal(res.total);
      setTotalPages(res.totalPages);
    } catch (err: any) {
      console.error('Failed to load customers', err);
    } finally {
      setIsLoading(false);
    }
  }, [
    page,
    limit,
    searchValue,
    filters.riskLevel,
    filters.mrrRange,
    filters.plan,
    filters.factor,
    sortBy,
    sortOrder
  ]);

  // Fetch all customers for dashboard summary
  const loadAllCustomers = useCallback(async () => {
    try {
      const res = await apiService.fetchCustomers({ limit: 200 });
      setAllCustomers(res.customers);
    } catch (err) {
      console.error('Failed to load all customers', err);
    }
  }, []);

  // Fetch integrations
  const loadIntegrations = async () => {
    try {
      const res = await apiService.fetchIntegrations();
      setIntegrations(res.integrations);
    } catch (err) {
      console.error('Failed to load integrations', err);
    }
  };

  // Fetch alerts
  const loadAlerts = async () => {
    try {
      const res = await apiService.fetchAlerts();
      setAlerts(res.alerts);
    } catch (err) {
      console.error('Failed to load alerts', err);
    }
  };

  // Health check for Gemini
  const checkHealth = async () => {
    try {
      const res = await apiService.fetchHealth();
      setGeminiReady(res.geminiConfigured);
    } catch (err) {
      setGeminiReady(false);
    }
  };

  // Initial load for integrations, alerts, health and summary data
  useEffect(() => {
    loadAllCustomers();
    loadIntegrations();
    loadAlerts();
    checkHealth();
  }, [loadAllCustomers]);

  // Load paginated customers on mount and when pagination, search, or filters change
  useEffect(() => {
    loadCustomers();
  }, [loadCustomers]);

  // Handle Search
  const handleSearchChange = (val: string) => {
    setSearchValue(val);
    setPage(1);
  };

  // Handle Filters
  const handleFilterChange = (key: string, val: string) => {
    setFilters((prev) => ({ ...prev, [key]: val }));
    setPage(1);
  };

  // Handle Sort
  const handleSortChange = (field: string) => {
    if (sortBy === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
    setPage(1);
  };

  // Gemini AI Score recalculation
  const handleRunAiPredict = async (customerId: string) => {
    try {
      setIsAiLoading(true);
      const updatedCust = await apiService.predictChurn(customerId);
      setCustomers((prev) => prev.map((c) => (c.id === customerId ? updatedCust : c)));
      setAllCustomers((prev) => prev.map((c) => (c.id === customerId ? updatedCust : c)));
      showToast(`AI Recalculated Churn Risk: ${updatedCust.riskScore} (${updatedCust.riskCategory})`);
    } catch (err: any) {
      showToast(err.message || 'AI prediction failed', 'error');
    } finally {
      setIsAiLoading(false);
    }
  };

  // Gemini AI Retention Playbook recommendation
  const handleRunAiRecommend = async (customerId: string) => {
    try {
      setIsAiLoading(true);
      const updatedCust = await apiService.recommendRetention(customerId);
      setCustomers((prev) => prev.map((c) => (c.id === customerId ? updatedCust : c)));
      setAllCustomers((prev) => prev.map((c) => (c.id === customerId ? updatedCust : c)));
      showToast(`Generated retention playbook for ${updatedCust.name}`);
    } catch (err: any) {
      showToast(err.message || 'Failed to generate recommendation', 'error');
    } finally {
      setIsAiLoading(false);
    }
  };

  // Mark customer saved
  const handleMarkSaved = async (customerId: string) => {
    try {
      const updatedCust = await apiService.markCustomerSaved(customerId);
      setCustomers((prev) => prev.map((c) => (c.id === customerId ? updatedCust : c)));
      setAllCustomers((prev) => prev.map((c) => (c.id === customerId ? updatedCust : c)));
      showToast(`Marked ${updatedCust.name} as Saved! MRR preserved.`);
    } catch (err: any) {
      showToast('Failed to update customer status', 'error');
    }
  };

  // Record outcome for Closed-Loop Learning
  const handleRecordOutcome = async (data: {
    customerId: string;
    status: 'recovered' | 'churned';
    churnReason?: ChurnReasonType;
    churnReasonDetail?: string;
    rescuePlaybookUsed?: string;
    mrrProtected?: number;
    notes?: string;
  }) => {
    try {
      const targetCust = allCustomers.find((c) => c.id === data.customerId);
      const customerName = targetCust?.name || 'Customer';
      const mrrValue = data.mrrProtected ?? targetCust?.mrr ?? 1200;

      const updatedFields: Partial<Customer> = {
        status: data.status === 'recovered' ? 'saved' : 'churned',
        outcomeStatus: data.status,
        churnReason: data.churnReason,
        churnReasonDetail: data.churnReasonDetail,
        rescuePlaybookUsed: data.rescuePlaybookUsed,
        mrrProtected: data.status === 'recovered' ? mrrValue : 0
      };

      setCustomers((prev) =>
        prev.map((c) => (c.id === data.customerId ? { ...c, ...updatedFields } : c))
      );
      setAllCustomers((prev) =>
        prev.map((c) => (c.id === data.customerId ? { ...c, ...updatedFields } : c))
      );

      if (data.status === 'recovered') {
        showToast(`🎉 Protected $${mrrValue.toLocaleString()} MRR for ${customerName}! Logged to closed-loop analytics.`, 'success');
      } else {
        showToast(`Attribution logged: ${data.churnReason || 'Churn'} recorded for ${customerName}. Recalibrating health weights.`, 'info');
      }
    } catch (err) {
      showToast('Failed to log outcome', 'error');
    }
  };

  // Batch Analyze All At-Risk Customers
  const handleBatchAnalyze = async () => {
    try {
      setIsBatchAnalyzing(true);
      showToast('Running Gemini batch churn prediction on all active customers...', 'info');
      const res = await apiService.batchAnalyze();
      await loadCustomers();
      await loadAllCustomers();
      showToast(res.message);
    } catch (err: any) {
      showToast('Batch analysis encountered an issue', 'error');
    } finally {
      setIsBatchAnalyzing(false);
    }
  };

  // Sync All Data Sources
  const handleSyncAll = async () => {
    try {
      setIsSyncing(true);
      showToast('Syncing integrations: Razorpay, Mixpanel, Intercom, SendGrid, Supabase...', 'info');
      const res = await apiService.syncAllIntegrations();
      setIntegrations(res.integrations);
      await loadCustomers();
      await loadAllCustomers();
      showToast('All data integrations synced successfully! Models refreshed.');
    } catch (err) {
      showToast('Sync failed', 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  // Sync One Data Source
  const handleSyncOne = async (id: string) => {
    try {
      setIsSyncing(true);
      const res = await apiService.syncIntegration(id);
      setIntegrations((prev) => prev.map((item) => (item.id === id ? res.integration : item)));
      await loadCustomers();
      await loadAllCustomers();
      showToast(`Synced ${res.integration.name} (${res.integration.syncedRecordsCount} records).`);
    } catch (err) {
      showToast('Sync failed', 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  // Toggle Integration
  const handleToggleIntegration = async (id: string, enabled: boolean) => {
    try {
      const res = await apiService.toggleIntegration(id, enabled);
      setIntegrations((prev) => prev.map((item) => (item.id === id ? res.integration : item)));
      showToast(`${res.integration.name} is now ${enabled ? 'Connected' : 'Disconnected'}`);
    } catch (err) {
      showToast('Failed to update integration state', 'error');
    }
  };

  // Import custom CSV, PDF, or mock JSON customers
  const handleImportCustomers = async (payload: {
    rawCsv?: string;
    rawPdfBase64?: string;
    fileType?: 'csv' | 'pdf';
    customers?: any[];
    fileName?: string;
    deduplicationMode?: 'overwrite' | 'skip';
    validateOnly?: boolean;
    importValidOnly?: boolean;
  }) => {
    const res = await apiService.importCustomersData(payload);
    await loadCustomers();
    await loadAllCustomers();
    return res;
  };

  // Send Test Digest
  const handleSendTestDigest = async (email: string, slackWebhook?: string) => {
    const res = await apiService.sendTestAlert(email, slackWebhook);
    showToast('Dispatched morning test digest via email & webhook!');
    return res;
  };

  // Auth Handlers
  const handleLogout = async () => {
    await authService.logout();
    setCurrentUser(null);
    setUserAwaiting2FA(null);
    showToast('You have been signed out successfully.', 'info');
    handleNavigate('login');
  };

  const handleAuthSuccess = () => {
    const user = authService.getCurrentUser();
    setCurrentUser(user);
    setUserAwaiting2FA(null);
    showToast('Welcome back! NoChurn is active.', 'success');
    const redirectUrl = authService.resolvePostLoginRedirect();
    if (redirectUrl === '/billing/verify') {
      handleNavigate('billing_verify');
    } else if (redirectUrl === '/pricing') {
      handleNavigate('pricing');
    } else {
      handleNavigate('dashboard');
    }
  };

  const handleRequireTwoFactor = (user: UserProfile) => {
    setUserAwaiting2FA(user);
    handleNavigate('2fa-prompt');
  };

  // Currently selected customer object
  const activeCustomer = selectedCustomerId
    ? allCustomers.find((c) => c.id === selectedCustomerId) ||
      customers.find((c) => c.id === selectedCustomerId) ||
      null
    : null;

  const atRiskCount = allCustomers.filter((c) => c.riskScore >= 61 && c.status !== 'saved').length;

  // Check if current view is a standalone Auth or Checkout View
  const isAuthView = [
    'login',
    'signup',
    '2fa-prompt',
    'forgot-password',
    'reset-password',
    'billing_verify',
    'billing/verify',
    'success'
  ].includes(activeView);

  // Check if current view is a standalone Legal View
  const isLegalView = [
    'security',
    'privacy',
    'terms',
    'dpa',
    'cookies',
    'acceptable-use',
    'contact',
    'help'
  ].includes(activeView);

  // Loading state guard: prevent brief flash of protected data while checking session
  if (!authInitialized) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <div className="flex flex-col items-center gap-3">
          <div className="w-9 h-9 border-3 border-blue-900 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-semibold text-gray-600">Verifying session...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 flex flex-col font-sans selection:bg-blue-900 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div
            className={`px-4 py-3 rounded-xl shadow-lg border text-xs font-semibold flex items-center gap-2.5 ${
              toastMessage.type === 'error'
                ? 'bg-red-900 text-white border-red-800'
                : 'bg-blue-900 text-white border-blue-800'
            }`}
          >
            {toastMessage.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-red-300" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Top Navigation Bar */}
      <Navbar
        searchValue={searchValue}
        onSearchChange={handleSearchChange}
        onNavigate={handleNavigate}
        alerts={alerts}
        onOpenCustomer={(id) => setSelectedCustomerId(id)}
        onOpenPricing={() => handleNavigate('pricing')}
        onOpenSecurity={() => handleNavigate('settings/security')}
        geminiReady={geminiReady}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenOnboarding={() => setShowOnboarding(true)}
      />

      {/* Demo Sandbox Alert Banner */}
      {!dismissDemoBanner && !isAuthView && (
        <div className="bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 border-b border-amber-200/90 px-4 py-2.5 text-xs text-amber-950 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-md bg-amber-200/90 font-black text-[10px] uppercase tracking-wider text-amber-950 border border-amber-300">
              Demo Sandbox Active
            </span>
            <span className="font-medium text-amber-900">
              Operating on sample B2B SaaS accounts (Indian SaaS & global cohorts). Real client data is logically isolated.
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowOnboarding(true)}
              className="px-2.5 py-1 bg-amber-900 hover:bg-amber-800 text-white rounded-lg font-bold text-[11px] transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-3 h-3 text-amber-200" />
              <span>4-Step Setup Flow</span>
            </button>
            <button
              onClick={() => handleNavigate('integrations')}
              className="px-2.5 py-1 bg-white hover:bg-amber-100/60 border border-amber-300 text-amber-900 rounded-lg font-semibold text-[11px] transition-colors cursor-pointer"
            >
              Connect Real APIs
            </button>
            <button
              onClick={() => setDismissDemoBanner(true)}
              className="text-amber-700 hover:text-amber-950 text-xs px-1 cursor-pointer"
              title="Dismiss banner"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* RENDER VIEW ACCORDING TO ROUTE */}
      {/* 1. AUTH & CHECKOUT SUCCESS VIEWS */}
      {isAuthView && (
        <div className="flex-1 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8">
          {activeView === 'login' && (
            <LoginView
              onNavigate={handleNavigate}
              onShowToast={showToast}
              onAuthenticated={handleAuthSuccess}
              onRequireTwoFactor={handleRequireTwoFactor}
              initialEmail={routeParams.email}
              verifiedMessage={routeParams.verified === 'true'}
            />
          )}

          {activeView === 'signup' && (
            <SignupView
              onNavigate={handleNavigate}
              onShowToast={showToast}
              onAuthenticated={handleAuthSuccess}
              initialPlan={routeParams.plan || 'growth'}
              routeParams={routeParams}
            />
          )}

          {(activeView === 'success' || activeView === 'payment-success') && (
            <SuccessView
              sessionId={routeParams.session_id}
              plan={routeParams.plan || 'growth'}
              billing={routeParams.billing === 'annual' ? 'annual' : 'monthly'}
              amount={routeParams.amount}
              onNavigate={handleNavigate}
            />
          )}

          {activeView === '2fa-prompt' && (
            <TwoFactorPromptView
              user={userAwaiting2FA || currentUser || authService.getCurrentUser()!}
              onNavigate={handleNavigate}
              onShowToast={showToast}
              onAuthenticated={handleAuthSuccess}
            />
          )}

          {activeView === 'forgot-password' && (
            <ForgotPasswordView
              onNavigate={handleNavigate}
              onShowToast={showToast}
            />
          )}

          {activeView === 'reset-password' && (
            <ResetPasswordView
              token={routeParams.token || 'demo-token-123'}
              onNavigate={handleNavigate}
              onShowToast={showToast}
            />
          )}

          {(activeView === 'billing_verify' || activeView === 'billing/verify') && (
            <BillingVerifyView
              onNavigate={handleNavigate}
              onShowToast={showToast}
            />
          )}
        </div>
      )}

      {/* 2. LEGAL & COMPLIANCE VIEWS */}
      {!isAuthView && isLegalView && (
        <div className="flex-1 py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
          {activeView === 'security' && (
            <SecurityTermsView onNavigate={handleNavigate} onShowToast={showToast} />
          )}

          {activeView === 'privacy' && (
            <PrivacyPolicyView onNavigate={handleNavigate} onShowToast={showToast} />
          )}

          {['terms', 'dpa', 'cookies', 'acceptable-use', 'contact', 'help'].includes(activeView) && (
            <LegalPagesView
              page={activeView as 'terms' | 'dpa' | 'cookies' | 'acceptable-use' | 'contact' | 'help'}
              onNavigate={handleNavigate}
              onShowToast={showToast}
            />
          )}
        </div>
      )}

      {/* 3. CORE APP VIEWS (WITH SIDEBAR) */}
      {!isAuthView && !isLegalView && (
        <div className="flex-1 flex w-full max-w-[1700px] mx-auto">
          {/* Desktop Sidebar */}
          <div className="hidden lg:block">
            <Sidebar
              activeView={activeView}
              onNavigate={handleNavigate}
              totalCustomers={allCustomers.length || total}
              atRiskCount={atRiskCount}
              onOpenPricing={() => handleNavigate('pricing')}
            />
          </div>

          {/* Main Content Area */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
            {/* Mobile Tab Bar */}
            <div className="lg:hidden flex items-center gap-2 overflow-x-auto pb-3 mb-4 scrollbar-none text-xs font-semibold">
              {[
                { id: 'action-queue', label: 'Action Queue (P1)' },
                { id: 'dashboard', label: 'Dashboard' },
                { id: 'closed-loop', label: 'Closed-Loop' },
                { id: 'roadmap', label: 'Roadmap' },
                { id: 'customers', label: 'Customers' },
                { id: 'playbooks', label: `Playbooks (${atRiskCount})` },
                { id: 'integrations', label: 'Import Data' },
                { id: 'analytics', label: 'Analytics' },
                { id: 'roi', label: 'ROI & Reports' },
                { id: 'alerts', label: 'Alerts' },
                { id: 'pricing', label: 'Pricing' },
                { id: 'settings/billing', label: 'Billing' },
                { id: 'settings/security', label: '2FA Security' },
                { id: 'settings/sessions', label: 'Sessions' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => handleNavigate(tab.id)}
                  className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
                    activeView === tab.id
                      ? 'bg-blue-900 text-white'
                      : 'bg-white border border-gray-200 text-gray-700'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Core Views */}
            {activeView === 'action-queue' && (
              <ActionQueueView
                customers={allCustomers}
                onSelectCustomer={(c) => setSelectedCustomerId(c.id)}
                onRecordOutcome={handleRecordOutcome}
                onShowToast={showToast}
                onNavigate={handleNavigate}
              />
            )}

            {activeView === 'closed-loop' && (
              <ClosedLoopLearningView
                customers={allCustomers}
                onSelectCustomer={(c) => setSelectedCustomerId(c.id)}
                onRecordOutcome={handleRecordOutcome}
              />
            )}

            {activeView === 'roadmap' && <RoadmapMetricsView />}

            {activeView === 'dashboard' && (
              <DashboardView
                customers={customers}
                allCustomers={allCustomers}
                total={total}
                page={page}
                limit={limit}
                totalPages={totalPages}
                onPageChange={setPage}
                onLimitChange={setLimit}
                onSearchChange={handleSearchChange}
                searchValue={searchValue}
                onFilterChange={handleFilterChange}
                filters={filters}
                onSortChange={handleSortChange}
                sortBy={sortBy}
                sortOrder={sortOrder}
                onSelectCustomer={(cust) => setSelectedCustomerId(cust.id)}
                onBatchAnalyze={handleBatchAnalyze}
                isBatchAnalyzing={isBatchAnalyzing}
                onMarkSaved={handleMarkSaved}
                onNavigate={handleNavigate}
                currentUser={currentUser}
              />
            )}

            {activeView === 'customers' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-gray-900">All SaaS Accounts ({allCustomers.length})</h2>
                    <p className="text-xs text-gray-700">Detailed customer profiles, telemetry, and churn risk scoring.</p>
                  </div>
                </div>

                <CustomerTableView
                  customers={customers}
                  total={total}
                  page={page}
                  limit={limit}
                  totalPages={totalPages}
                  onPageChange={setPage}
                  onLimitChange={setLimit}
                  onSearchChange={handleSearchChange}
                  searchValue={searchValue}
                  onFilterChange={handleFilterChange}
                  filters={filters}
                  onSortChange={handleSortChange}
                  sortBy={sortBy}
                  sortOrder={sortOrder}
                  onSelectCustomer={(cust) => setSelectedCustomerId(cust.id)}
                  onBatchAnalyze={handleBatchAnalyze}
                  isBatchAnalyzing={isBatchAnalyzing}
                  onMarkSaved={handleMarkSaved}
                />
              </div>
            )}

            {activeView === 'playbooks' && (
              <RetentionPlaybooksView
                customers={allCustomers}
                onSelectCustomer={(cust) => setSelectedCustomerId(cust.id)}
                onRunAiRecommend={handleRunAiRecommend}
                onMarkSaved={handleMarkSaved}
                isAiLoading={isAiLoading}
              />
            )}

            {activeView === 'integrations' && (
              <DataIntegrationView
                integrations={integrations}
                onSyncAll={handleSyncAll}
                onSyncOne={handleSyncOne}
                onToggleIntegration={handleToggleIntegration}
                onImportCustomers={handleImportCustomers}
                isSyncing={isSyncing}
                onNavigate={handleNavigate}
                onShowToast={showToast}
              />
            )}

            {activeView === 'analytics' && <AnalyticsView customers={allCustomers} />}

            {activeView === 'roi' && (
              <RoiCalculatorView customers={allCustomers} onShowToast={showToast} />
            )}

            {activeView === 'alerts' && (
              <DailyAlertsView
                alerts={alerts}
                onOpenCustomer={(id) => setSelectedCustomerId(id)}
                onSendTestDigest={handleSendTestDigest}
              />
            )}

            {activeView === 'pricing' && (
              <PricingView
                onSelectPlan={(id) => showToast(`Selected ${id.toUpperCase()} tier plan`)}
                onNavigate={handleNavigate}
                onShowToast={showToast}
                initialPlan={routeParams.plan || 'growth'}
              />
            )}

            {/* Billing & Subscription View */}
            {(activeView === 'settings/billing' || activeView === 'billing') && (
              <BillingSettingsView
                currentUser={currentUser}
                onNavigate={handleNavigate}
                onShowToast={showToast}
                onUpdateUser={(updated) => setCurrentUser(updated)}
                initialAction={routeParams.action}
              />
            )}

            {/* Admin Billing Plans View (/admin/billing/plans) */}
            {(activeView === 'admin/billing/plans' || activeView === 'admin-plans' || activeView === 'admin/plans') && (
              <AdminBillingPlansView
                onNavigate={handleNavigate}
                onShowToast={showToast}
              />
            )}

            {/* Settings Views: 2FA, Active Sessions, and Governance */}
            {(activeView === 'settings/security' || activeView === 'security-settings') && (
              <SecurityView
                initialTab="2fa"
                onNavigate={handleNavigate}
                onShowToast={showToast}
                onLoggedOut={handleLogout}
              />
            )}

            {activeView === 'settings/sessions' && (
              <SecurityView
                initialTab="sessions"
                onNavigate={handleNavigate}
                onShowToast={showToast}
                onLoggedOut={handleLogout}
              />
            )}

            {activeView === 'settings/governance' && (
              <SecurityView
                initialTab="governance"
                onNavigate={handleNavigate}
                onShowToast={showToast}
                onLoggedOut={handleLogout}
              />
            )}

            {(activeView === 'admin/db-test' || activeView === 'admin-db-test') && (
              <AdminDatabaseTestView />
            )}
          </main>
        </div>
      )}

      {/* Global Comprehensive Footer with all compliance & support links */}
      <Footer onNavigate={handleNavigate} />

      {/* Customer Detail & AI Playbook Modal */}
      {activeCustomer && (
        <CustomerDetailModal
          customer={activeCustomer}
          onClose={() => setSelectedCustomerId(null)}
          onRunAiPredict={handleRunAiPredict}
          onRunAiRecommend={handleRunAiRecommend}
          onMarkSaved={handleMarkSaved}
          isAiLoading={isAiLoading}
        />
      )}

      {/* 4-Step Retention OS First-Value Onboarding Modal */}
      <OnboardingModal
        isOpen={showOnboarding}
        currentUser={currentUser}
        onClose={() => setShowOnboarding(false)}
        onComplete={() => {
          setShowOnboarding(false);
          handleNavigate('action-queue');
          showToast('First-value onboarding complete! First retention action queue unlocked.', 'success');
        }}
        onLoadDemoData={async () => {
          await loadCustomers();
          await loadAllCustomers();
          showToast('Loaded 50 curated SaaS B2B retention records!', 'success');
        }}
        onImportCsv={async (file: File) => {
          const text = await file.text();
          await handleImportCustomers({
            rawCsv: text,
            fileType: 'csv',
            fileName: file.name,
            deduplicationMode: 'overwrite'
          });
          showToast(`Successfully imported ${file.name}!`, 'success');
        }}
        onFirstActionTaken={(cust) => {
          handleMarkSaved(cust.id);
        }}
        topCustomer={allCustomers.find((c) => c.riskCategory === 'Critical') || allCustomers[0] || null}
        customers={allCustomers}
      />
    </div>
  );
}
